import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
from CommonFunctions import stripTags
import inputstreamhelper


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.playpuls')
resources = xbmc.translatePath(addon.getAddonInfo('path') + '/resources/')
main_url = 'http://playpuls.pl'

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, thumb, cover, is_folder, is_playble, payload, plot=''):
    list_item = xbmcgui.ListItem(label=name)

    if is_playble:
        list_item.setProperty("IsPlayable", 'true')
    else:
        list_item.setProperty("IsPlayable", 'false')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name, 'plot': plot})
    list_item.setArt({'thumb': thumb, 'poster': cover, 'banner': thumb, 'fanart': thumb})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=is_folder
    )


def home():
    add_item('PREMIERY', '', '', True, False, {'mode': 'season', 'path': '/'})
    add_item('SERIALE', '', '', True, False, {'mode': 'list', 'path': '/seriale'})
    add_item('DOKUMENTY', '', '', True, False, {'mode': 'list', 'path': '/dokumenty'})
    add_item('ROZRYWKA', '', '', True, False, {'mode': 'list', 'path': '/rozrywka'})
    add_item('PORADNIKI', '', '', True, False, {'mode': 'list', 'path': '/poradniki'})
    add_item('LAST MINUTE', '', '', True, False, {'mode': 'list', 'path': '/last-minute'})
    xbmcplugin.endOfDirectory(addon_handle)


def list():
    path = params.get('path', None)

    response = requests.get(
        main_url + path,
        verify=False
    )

    main = parseDOM(parseDOM(response.content, 'div', attrs={'id': 'main'})[0], 'div', attrs={'class': 'view-content'})[0]
    links = parseDOM(main, 'a', ret='class')
    paths = parseDOM(main, 'a', ret='href')
    items = parseDOM(main, 'a')

    def add_list_item(item, path):
        covers = parseDOM(item, 'img', attrs={'class': 'cover'}, ret='src')
        if len(covers) > 0:
            cover = covers[-1]
        else:
            cover = ''

        screenshots = parseDOM(item, 'img', attrs={'class': 'screenshot'}, ret='src')
        if len(screenshots) > 0:
            screenshot = screenshots[-1]
        else:
            screenshot = ''

        descriptions = parseDOM(item, 'div', attrs={'class': 'video-description'})
        desc = parseDOM(descriptions[0], 'p')
        if len(desc) > 1:
            plot = stripTags(desc[1])
        else:
            plot = ''

        add_item(
            name=desc[0],
            thumb=screenshot,
            cover=cover,
            is_folder=True,
            is_playble=False,
            payload={'mode': 'season', 'path': path},
            plot=plot
        )

    for index, link in enumerate(links):
        item = items[index]
        if 'node' not in link.encode('utf-8'):
            add_list_item(item, paths[index])

    xbmcplugin.endOfDirectory(addon_handle)


def season():
    main_path = params.get('path', None)
    response = requests.get(
        main_url + main_path,
        verify=False
    )

    if main_path == '/':
        main = parseDOM(response.content, 'div', attrs={'id': 'block-views-seriale-block-1'})[0]
    else:
        main = parseDOM(response.content, 'div', attrs={'class': 'view layout layout-small layout-full'})

    descriptions = parseDOM(main, 'div', attrs={'class': 'video-description'})
    links = parseDOM(main, 'a', ret='class')
    paths = parseDOM(main, 'a', ret='href')
    items = parseDOM(main, 'a')

    def add_list_item(item, path, id):
        covers = parseDOM(item, 'img', attrs={'class': 'cover'}, ret='src')
        if len(covers) > 0:
            cover = covers[-1]
        else:
            cover = ''

        screenshots = parseDOM(item, 'img', attrs={'class': 'screenshot'}, ret='src')
        if len(screenshots) > 0:
            screenshot = screenshots[-1]
        else:
            screenshot = ''

        desc = parseDOM(descriptions[index], 'p')

        if len(desc) > 1:
            plot = stripTags(desc[1])
        else:
            plot = ''

        title_items = parseDOM(item, 'span', attrs={'class': 'video-caption-episode'})
        if len(title_items) > 0:
            title = title_items[0]
        else:
            title = desc[0]

        if main_path == '/':
            title = desc[0]

        add_item(
            name=title,
            thumb=screenshot,
            cover=cover,
            is_folder=False,
            is_playble=True,
            payload={'mode': 'play', 'path': path, 'id': id},
            plot=plot
        )

    for index, link in enumerate(links):
        item = items[index]
        if 'node' in link.encode('utf-8'):
            id = link.encode('utf-8').split(' ')[1].split('-')[1]
            if id:
                add_list_item(item, paths[index], id)

    xbmcplugin.endOfDirectory(addon_handle)


def play():
    id = params.get('id', None)
    print('play id ' + id)
    if id:
        response = requests.get(
            main_url + '/sites/all/modules/vod/player.php',
            params={'id': id},
            verify=False
        ).json()

        sources = response.get('sources', {})

        url = None

        if addon.getSetting('quality') == '0':
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('D3') + '/manifest.mpd'
        elif addon.getSetting('quality') == '1':
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('D2') + '/manifest.mpd'
        elif addon.getSetting('quality') == '2':
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('D1') + '/manifest.mpd'
        elif addon.getSetting('quality') == '3':
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('M2') + '/manifest.mpd'
        elif addon.getSetting('quality') == '4':
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('M1') + '/manifest.mpd'

        if not url:
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('D2') + '/manifest.mpd'
        if not url:
            url = 'http://vod1.playpuls.pl:1716/Edge/_definst_/mp4:s3/play/' + sources.get('M2') + '/manifest.mpd'

        if url:
            is_helper = inputstreamhelper.Helper('mpd')
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url)
                play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                play_item.setContentLookup(False)
                play_item.setMimeType('application/dash+xml')
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'list':
        list()
    elif mode == 'season':
        season()
    elif mode == 'play':
        play()
