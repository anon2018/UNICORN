# -*- coding: utf-8 -*-

import re,os, sys, time, json
import xbmc, xbmcgui
import urllib, urllib2

import db, PhantomCommon, common
cm      = PhantomCommon.common()
cmn     = common

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36',}

def log(msg): xbmc.log(msg,level=xbmc.LOGNOTICE)

def getMeta(items):
    idlist = []
    for item in items:
        idlist.append(item['id_stream'])
    idlist = str(idlist)
    if db.readParam(4):
        exec (db.getQuery(4.007))
    else:
        response = ''
    data = re.compile('ids=(.*?),items=(.*?)koniec_meta', flags=re.S).findall(response)
    ids = json.loads(data[0][0]) if data else ''
    infos = json.loads(data[0][1]) if data else ''
    dp = xbmcgui.DialogProgressBG()
    dp.create('','')
    itemslen = len(items)
    for i in range(itemslen):
        id_stream = items[i]['id_stream']
        if id_stream in ids:
            dursec = items[i]['dursec']
            idx = ids.index(id_stream)
            items[i] = infos[idx]
            items[i]['dursec'] = dursec
        elif items[i]['dursec']>=3600:
            dp.update(i*100/itemslen,str(i+1)+'/'+str(itemslen),items[i]['title_stream'].encode("utf-8"))
            info = filmweb_search(items[i], 1)
            watchlvl = 0
            res_play = ''
            owner = ''
            exec (db.getQuery(8.005))
            items[i] = info
    dp.close()
    return items

def filmweb_search(item, par):
    items = []
    search_url = 'http://www.filmweb.pl/films/search?q=%s' % urllib.quote_plus(item['title_cln'].encode("utf-8"))
    link = getLink(search_url)
    results = re.compile('filmPreview--FILM(.*?)</div></div></div></div>').findall(link)
    for result in results:
        fitems = re.compile('data-film="(.*?)"(.*?)src="(.*?)"(.*?)href="(.*?)"(.*?)title">(.*?)<(.*?)year">(.*?)<').findall(result)
        rating = re.search('rateBox__rate">(.*?)<', result)
        rating = rating.group(1).replace(',','.') if rating else ''
        for fitem in fitems:
            items.append({'id_film':fitem[0], 'icon':fitem[2].replace('.6.jpg','.3.jpg'), 'url_film':'http://www.filmweb.pl'+fitem[4], 'title_film':fitem[6], 'year':fitem[8], 'rating' : rating})
    if par == 0:
        return items
    elif par == 1:
        counter = len(items)
        for pitem in items:
            title_u = unicode(pitem['title_film'],'utf-8')
            if counter == 1 or item['year'] == pitem['year']:
                item['id_film'] = pitem['id_film']
                item['url_film'] = pitem['url_film']
                item['title_stream'] = title_u
                item['title_cln'] = title_u
                item['year'] = pitem['year']
                item['icon'] = pitem['icon']
                item['rating'] = pitem['rating']
                item['savelvl'] = 1
                break
        return item


def get_filmweb_details(item, savelvl):
    url = item.get('url_film')
    link = getLink(url)
    data = re.compile('call\(window,{id:(.*?),(.*?)title:"(.*?)"(.*?)year:(.*?),').findall(link)
    rating = re.search('ratingValue"> (.*?)<', link)
    item['rating'] = rating.group(1).replace(',','.') if rating else ''
    plot = re.compile('itemprop="description">(.{4,}?)</').findall(link)
    if plot:
        if plot[-1] <> '...</span>':
            item['plot'] = unicode(cmn.htmlSpecialChars(plot[-1].replace('<span class="fullText hide">','')),'utf-8')
    icon = re.search('og:image" content="(.*?)"', link)
    if icon:
        item['icon'] = icon.group(1)
    item['id_film'] = data[0][0]
    title_u = unicode(data[0][2],'utf-8')
    item['title_stream'] = title_u
    item['title_cln'] = title_u
    item['year'] = data[0][4]
    item['savelvl'] = savelvl
    return item

def tmdb_search(item, par):
    items = []
    search_url = 'https://www.themoviedb.org/search/movie?query=%s&language=pl-PL' % urllib.quote_plus(item['title_cln'].encode("utf-8"))
    link = getLink(search_url)
    results = re.compile('item poster card(.*?)Więcej informacji', re.DOTALL).findall(link)
    for result in results:
        fitems = re.compile('movie_(.*?)"(.*?)title="(.*?)"(.*?)jpg 1x,(.*?)2x(.*?)<span>(.*?)<', re.DOTALL).findall(result)
        plot = re.search('overview">(.*?)<', result)
        for fitem in fitems:
            items.append({'id_film':fitem[0], 'icon':fitem[4].replace(' ',''), 'url_film':'https://www.themoviedb.org/movie/'+fitem[0]+'?language=pl-PL', 'title_film':fitem[2], 'year':fitem[6][-4:]})
    if par == 0:
        return items

def get_tmdb_details(item):
    url = item.get('url_film')
    link = getLink(url)
    id_tmdb = re.search('movie/(.*?)\?', url)
    title = re.search('<title>(.*?)\((.*?)\)', link)
    title_u = unicode(title.group(1),'utf-8')
    icon = re.search('og:image" content="(.*?)"', link)
    plot = re.search('<meta name="description" content="(.*?)"', link)
    rating = re.search('data-percent="(.*?)\.', link)
    rt = rating.group(1)
    item['plot'] = unicode(cmn.htmlSpecialChars(plot.group(1).replace('<span class="fullText hide">','')),'utf-8')
    item['id_tmdb'] = id_tmdb.group(1)
    item['title_stream'] = title_u
    item['title_cln'] = title_u
    item['icon'] = icon.group(1)
    item['year'] = title.group(2)
    item['rating'] = rt[0]+'.'+rt[1] if len(rt)==2 else '0.0'
    item['savelvl'] = 0 if item['savelvl'] == 0 else 2
    return item

def getLink(url):
        req = urllib2.Request(url, None, headers)
        try:
            response = urllib2.urlopen(req,timeout = 10)
            link=response.read()
            response.close()
        except:
            link=''
        return link
