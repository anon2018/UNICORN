import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from datetime import datetime, timedelta
import time

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.espl')
resources = xbmc.translatePath(addon.getAddonInfo('path') + '/resources/')

headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'https://www.elevensports.pl'}

authenticate_url = 'https://www.elevensports.pl/secure/authenticate'
epg_main_url = 'http://smb.cdnllnwnl.neulion.com/u/mt1/elevensportspl/epg'
publishpoint_url = 'https://www.elevensports.pl/service/publishpoint'
vod_url = 'https://www.elevensports.pl/service/category'
thumbs_url = 'http://smb.cdnllnwnl.neulion.com/u/mt1/elevensportspl/thumbs/'

cookies = {}


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def epg_url(date):
    slug = params.get('slug', None)
    return epg_main_url + '/' + slug + '/' + str(date.year) + '/' + str(date.month).zfill(2) + '/' + str(
        date.day).zfill(
        2) + '.json'


def add_item(name, image, is_folder, is_playble, payload, plot=''):
    list_item = xbmcgui.ListItem(label=name)

    if is_playble:
        list_item.setProperty("IsPlayable", 'true')
    else:
        list_item.setProperty("IsPlayable", 'false')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name, 'plot': plot})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=is_folder
    )


def play():
    import re
    login()
    channel_id = params.get('channel_id', None)
    program_id = params.get('program_id', None)
    duration = params.get('duration', None)
    starttime = params.get('starttime', None)

    data = {'format': 'json'}

    if channel_id:
        data['id'] = channel_id
        data['type'] = 'channel'
    if program_id:
        data['id'] = program_id
        data['type'] = 'video'
    if duration:
        data['dur'] = duration
    if starttime:
        data['st'] = starttime

    if channel_id or program_id:
        response = requests.post(
            publishpoint_url,
            params=data,
            verify=False,
            headers=headers,
            cookies=cookies
        )
        path = response.json().get('path', None)
        nazwa = re.findall("live/(eleven.*?)\?", path)[0]
        path = path.replace(nazwa, params['jakosc'])
        xbmc.Player().play(path + "|User-Agent=vlc/3.0.0-git libvlc/3.0.0-git&verifypeer=false")


def login():
    global cookies

    username = addon.getSetting('username')
    password = addon.getSetting('password')

    if username and password:
        response = requests.post(
            authenticate_url,
            data={'username': username, 'password': password, 'cookielink': 'false'},
            verify=False,
            headers=headers
        )
        cookies = response.cookies
    else:
        xbmcgui.Dialog().ok('ELEVEN SPORTS', 'Podaj dane logowania w ustawieniach wtyczki.')
        xbmcaddon.Addon(id='plugin.video.espl').openSettings('Konto')


def epg():
    channel_id = params.get('id', None)
    now = datetime.now()
    yesterday = now - timedelta(days=1)

    yesterday_items = requests.post(
        epg_url(yesterday),
        verify=False,
        headers=headers,
        cookies=cookies
    ).json()[0].get('items', [])

    today_items = requests.post(
        epg_url(now),
        verify=False,
        headers=headers,
        cookies=cookies
    ).json()[0].get('items', [])

    if yesterday_items[-1].get('e', 'none') == today_items[0].get('e', 'none'):
        today_items.pop(0)

    def add_epg_item(item):
        try:
            start_date = datetime.strptime(item.get('sl', ''), '%Y-%m-%dT%H:%M:%S.%f')
        except TypeError:
            start_date = datetime(*(time.strptime(item.get('sl', ''), '%Y-%m-%dT%H:%M:%S.%f')[0:6]))

        try:
            start_u_date = datetime.strptime(item.get('su', ''), '%Y-%m-%dT%H:%M:%S.%f')
        except TypeError:
            start_u_date = datetime(*(time.strptime(item.get('su', ''), '%Y-%m-%dT%H:%M:%S.%f')[0:6]))

        title = '[B]' + start_date.strftime('%H:%M') + '[/B]' + '    ' + item.get('e', 'none')
        duration_minutes = item.get('d', 0)
        end_date = start_date + timedelta(minutes=duration_minutes)

        if start_date <= now and now <= end_date:
            title = '[B]TRWA[/B]    ' + '[B]' + item.get('e', 'none') + '[/B]'
            duration_ms = ''
            start_u_ms = ''
        else:
            duration_ms = str(duration_minutes * 60 * 1000)
            start_u_ms = str(int((start_u_date - datetime(1970, 1, 1)).total_seconds() * 1000))

        if start_date > now:
            title = '[COLOR gray]' + title + '[/COLOR]'

        add_item(title, resources + 'icon.png', True, False, {'mode': 'jakosc', 'channel_id': channel_id, 'duration': duration_ms, 'starttime': start_u_ms})

    add_item('[I]Wczoraj[/I]', resources + 'transparent.png', False, False, {})

    for item in yesterday_items:
        try:
            start_date = datetime.strptime(item.get('sl', ''), '%Y-%m-%dT%H:%M:%S.%f')
        except TypeError:
            start_date = datetime(*(time.strptime(item.get('sl', ''), '%Y-%m-%dT%H:%M:%S.%f')[0:6]))
        if start_date.hour > now.hour:
            add_epg_item(item)

    add_item('[I]Dzisiaj[/I]', resources + 'transparent.png', False, False, {})

    for item in today_items:
        add_epg_item(item)

    xbmcplugin.endOfDirectory(addon_handle)


def vod():
    response = requests.post(
        vod_url,
        params={'format': 'json', 'id': '509', 'ps': '999', 'pn': '1'},
        verify=False,
        headers=headers,
        cookies=cookies
    ).json()

    for item in response.get('programs', []):
        id = item.get('id', '')
        title = item.get('name', '')
        desc = item.get('description', '')
        image = thumbs_url + item.get('image', '')
        add_item(title, image, False, True, {'mode': 'play', 'program_id': id}, desc)
    xbmcplugin.endOfDirectory(addon_handle)


def home():
    add_item('ELEVEN SPORTS 1', resources + '1.png', True, False, {'mode': 'epg', 'id': '10', 'slug': 'elevensports1'})
    add_item('ELEVEN SPORTS 2', resources + '2.png', True, False, {'mode': 'epg', 'id': '11', 'slug': 'elevensports2'})
    add_item('ELEVEN SPORTS 3', resources + '3.png', True, False, {'mode': 'epg', 'id': '12', 'slug': 'elevensports3'})
    add_item('ELEVEN SPORTS 4', resources + '4.png', True, False, {'mode': 'epg', 'id': '37', 'slug': 'elevensports4'})
    add_item('VOD', resources + 'icon.png', True, False, {'mode': 'vod'})
    xbmcplugin.endOfDirectory(addon_handle)

def jakosc():
    import re
    login()
    channel_id = params.get('channel_id', None)
    program_id = params.get('program_id', None)
    duration = params.get('duration', None)
    starttime = params.get('starttime', None)

    data = {'format': 'json'}

    if channel_id:
        data['id'] = channel_id
        data['type'] = 'channel'
    if program_id:
        data['id'] = program_id
        data['type'] = 'video'
    if duration:
        data['dur'] = duration
    if starttime:
        data['st'] = starttime

    if channel_id or program_id:
        response = requests.post(
            publishpoint_url,
            params=data,
            verify=False,
            headers=headers,
            cookies=cookies
        )
        path = response.json().get('path', None)

        test = requests.get(path).content
        jakosci = re.findall("(BANDWIDTH=.*?)\n", test)
        linki = re.findall("(eleven.*?)\?", test)
        for item in zip(jakosci, linki):
            channel_id = params.get('channel_id', None)
            add_item(item[0], resources + '1.png', True, False, {'mode': 'play', 'channel_id': channel_id, 'jakosc': item[1]})
        xbmcplugin.endOfDirectory(addon_handle)


if __name__ == '__main__':
    mode = params.get('mode', None)

    if not mode:
        home()
    elif mode == 'play':
        play()
    elif mode == 'jakosc':
        jakosc()
    elif mode == 'epg':
        epg()
    elif mode == 'vod':
        vod()
