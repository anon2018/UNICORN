'''
    Our Match Add-on
    Copyright (C) 2016 123456

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmcplugin, xbmcgui, urllib, re, os, sys, time
from ptw.debug import log_exception, log, start_trace, stop_trace, TRACE_ALL
import dom_parser2
import client
import kodi
art       = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ourmatch/resources/art', ''))

def main(name=None, iconimage=None):

    c = client.request('http://ourmatch.net')
    if not iconimage: iconimage = kodi.addonicon
    if name:
        r = dom_parser2.parse_dom(c, 'li', {'class': 'header'})
        r = [i for i in r if 'title="%s"' % name in i.content]
        r = dom_parser2.parse_dom(r, 'li', {'class': 'hover-tg'})
        r = dom_parser2.parse_dom(r, 'a')
        for i in r:
            addDir(i.content,i.attrs['href'],3,iconimage)
    else:
        r = dom_parser2.parse_dom(c, 'a', {'class': 'sub'})
        addDir('Search...','search',3,art+'search.png')
        addDir('Most Recent','http://ourmatch.net/',3,art+'new.png')
        for i in r:
            addDir(i.attrs['title'],'none',2,art+i.attrs['title'].lower()+'.png')

def getMatches(url):

    if url == 'search':
        term = kodi.get_keyboard(heading='Search Our Match')
        if term: c  = client.request('http://ourmatch.net/?s=%s' % term.lower().replace(' ','+'))
        else: quit()
    else:
        c  = client.request(url)
    r = dom_parser2.parse_dom(c, 'div', {'class': 'vidthumb'})
    r = [(dom_parser2.parse_dom(i, 'span', {'class': 'time'}), \
          dom_parser2.parse_dom(i, 'a', req=['href','title']), \
          dom_parser2.parse_dom(i, 'img', req='src')) for i in r if i]
    r = [(re.sub('<.+?>', '', i[0][0].content), i[1][0].attrs['title'], i[1][0].attrs['href'], i[2][0].attrs['src']) for i in r]
    for i in r:
        addDir('%s - %s' % (i[0], i[1]), i[2], 4, i[3])   
    try:
        np = re.findall('''<link\s*rel=['"]next['"]\s*href=['"]([^'"]+)''', c)[0]
        addDir('Next Page -->', np, 3, art+'nextpage.png')
    except: pass

def getStreams(name,url,iconimage):
    c  = client.request(url)
    r = re.findall("\d+':\s*{embed:'([^}]+)", c)
    for i in r:
        try:
            src = re.findall('''src=['"]([^'"]+)''',i)[0]
            if not src.startswith('http'): src = 'https:' + src
            try: lang = re.findall('''lang:['"]([^'"]+)''',i)[0]
            except: lang = 'Unknown'
            try: name = re.findall('''['"]type['"]:['"]([^'"]+)''',i)[0]
            except: name = 'Unknown'
            try: quality = re.findall('''quality:['"]([^'"]+)''',i)[0]
            except: quality = 'Unknown'
            try: source = re.findall('''source:['"]([^'"]+)''',i)[0]
            except: source = 'Unknown'
            addDir('%s - %s - %s - %s' % (name, quality, lang, source),src,1,iconimage,isFolder=False)
        except: pass

def textboxGit(header=None,announce=None):
    class TextBox():
        WINDOW=10147
        CONTROL_LABEL=1
        CONTROL_TEXTBOX=5
        def __init__(self,*args,**kwargs):
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
            self.win=xbmcgui.Window(self.WINDOW) # get window
            xbmc.sleep(500) # give window time to initialize
            self.setControls()
        def setControls(self):
            if header == None: self.win.getControl(self.CONTROL_LABEL).setLabel(sys.args(0)) # set heading
            else: self.win.getControl(self.CONTROL_LABEL).setLabel(header) # set heading
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(announce))
            return
    announce = announce.encode('utf-8')
    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        time.sleep(.5)
        
def play(name,url):

    import resolveurl as urlresolver
    if urlresolver.HostedMediaFile(url).valid_url(): 
        url = urlresolver.HostedMediaFile(url).resolve()
    else:
        log("OurMatch.Link " + str(url))
        link  = client.request(url)
        match = re.compile('<source src="(.+?)" type="video/mp4" class="mp4-source"/>').findall(link)
        match_cv = re.compile('hls:"//(.*?)"').findall(link) #.replace('0.m3u8','720p.m3u8')
        for url in match:
            name = name
            url  = 'https:'+url
        if 'media.content-ventures.com' in url:
            url='http://' + match_cv[0]
        if 'oms.matchat.online' in url:
            log(str(url))
            url='http://' + match_cv[0]
    stream_url = url
    liz = xbmcgui.ListItem(name, path=stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        
def addDir(name,url,mode,iconimage,isFolder=True,isPlayable=True):
    try: client.replaceHTMLCodes(name)
    except: pass
    name = name.replace('&#038;','&')
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name} )
    liz.setProperty('fanart_image', kodi.addonfanart)
    if isPlayable: liz.setProperty("IsPlayable","true")
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]
                            
    return param
        
params=get_params()
url=None
name=None
mode=None
iconimage=None
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

if mode==None or url==None or len(url)<1: main()
elif mode==1: play(name,url)
elif mode==2: main(name, iconimage)
elif mode==3: getMatches(url)
elif mode==4: getStreams(name,url,iconimage)
elif mode==5: githubIssues()

xbmcplugin.endOfDirectory(int(sys.argv[1]))