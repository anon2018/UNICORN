﻿'''
Created on 11-08-2011

@author: Virus
'''

import sys
import re
import urllib
import urllib2

def getContent(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Tuba/2.6.1 CFNetwork/548.0.4 Darwin/11.0.0')
    response = urllib2.urlopen(req)
    content = response.read()
    response.close()
    return content

class Stream:
    app_path = '/stream.pls?radio=%d'

    def getStream(self, id):
        content = getContent(url + self.app_path % (id,))
        return content
        
    def getStreamURL(self, id):
        return url + self.app_path % (id,)

class PlaylistEntry:
    id = None
    artist = None
    id2 = None
    title = None
    album = None
    img = None
    filename = None
    link = None

class Playlist:
    app_path = '/api/_getDynamicPlaylist&format=json&sessionid=%s&id=%d&type=%d'
    playlist = [PlaylistEntry]
    playlist.pop()
    
    def getSongUrl(self, sessionId, id, filename):
        app_path = '/service/_getSongUrl&format=json&sessionid=%s&id=%d&filename=%s'
        content = getContent(url + app_path % (sessionId, id, filename.replace('\\/', '/') ,))
        result = re.findall('{"link":"(.+?)"}', content, re.IGNORECASE)
        result = str('http://storage.tuba.fm/mobile/' + result[0]).replace('\\/', '/')
        return result
    
    def getPlaylist(self, sessionId, id, type):
        content = getContent(url + self.app_path % (sessionId, id, type,))
        result = re.findall('\["(.+?)","(.+?)","(.+?)","(.+?)","(.*?)","(.+?)","(.+?)","(.+?)"\]', content, re.IGNORECASE)

        for item in result:
            pe = PlaylistEntry()
            pe.id = item[0]
            pe.artist = str(item[1]).decode('unicode-escape')
            pe.id2 = int(item[2])
            pe.title = str(item[3]).decode('unicode-escape')
            pe.album = str(item[4]).decode('unicode-escape')
            pe.img = '%s/zcovers/_img/%s' % (url_static, item[5],)
            pe.filename = self.getSongUrl(sessionId, pe.id2, item[6])
            pe.link = item[7]
            self.playlist.append(pe)

class SearchResults:
    types = ["podobni artyści", "stacje użytkownika", "stacje strumieniowe", 'wszystkie utwory', "radio gatunku", '5', '6', '7']
    type_str = None
    type = None
    id = None
    pid = None
    keyword = None
    power = None
    link = None
    user_login = None
    user_id = None

class Search:
    app_path = '/api/_cache_autocomplete?format=json&query=%s'
    app_type = '&type=%d'
    results = [SearchResults]
    results.pop()
    
    def doSearch(self, keyword, type):
        u = url + self.app_path % (keyword,)
        if type != None:
            u += self.app_type % (type,)
        content = getContent(u)
        result = re.findall('{"type":"(.+?)","id":"(.+?)"(,"pid":"(.+?)")?,"keyword":"(.+?)","power":"(.+?)","link":"(.+?)"(,"user_login":"(.+?)","user_id":"(.+?)")?}', content, re.IGNORECASE)

        for item in result:
            sr = SearchResults()
            sr.type_str = sr.types[int(item[0])]
            sr.type = int(item[0])
            sr.id = int(item[1])
            sr.pid = item[3]
            sr.keyword = str(item[4]).decode('unicode-escape')
            sr.power = item[5]
            sr.link = item[6]
            sr.user_login = item[8]
            sr.user_id = item[9]
            self.results.append(sr)
            
class Station:
    radio_id = None
    radio_name = None
    radio_img = None
    radio_description = None
    radio_link = None
    
class Stations:
    app_path = '/api/_getStations?limit=0&offset=0&format=json'
    stations = [Station]
    stations.pop()

    def getStations(self):
        content = getContent(url + self.app_path)
        result = re.findall('{"radio_id":"(.+?)","radio_name":"(.+?)","radio_img":"(.+?)","radio_description":"(.+?)","radio_link":"(.+?)"}', content, re.IGNORECASE)
        
        for item in result:
            s = Station()
            s.radio_id = int(item[0])
            s.radio_name = str(item[1]).decode('unicode-escape')
            s.radio_img = '%s/stations/_img/_glossy/%s' % (url_static, item[2],)
            s.radio_description = str(item[3]).decode('unicode-escape')
            s.radio_link = item[4]
            self.stations.append(s)
            
class Radio:
    radio_cache = None
    radio_name = None    
    radio_img = None
    radio_description = None
    radio_pid = None
    radio_id = None
    radio_link = None
    user_login = None
    user_id = None
    
class Radios:
    app_path_latest = '/api/_cache_getLatestRadios?format=json&limit=%d&offset=0'
    app_path_popular = '/api/_cache_getPopularRadios?format=json&limit=%d&offset=0'
    app_path_az = '/api/_cache_getAllRadios?limit=0&offset=0&format=json'
    radios = [Radio]
    radios.pop()

    def getLatest(self, limit):
        content = getContent(url + self.app_path_latest % (limit),)
        result = re.findall('{"radio_cache":"(.+?)","radio_name":"(.+?)","radio_img":"(.+?)","radio_description":"(.+?)","radio_pid":"(.+?)","radio_id":"(.+?)","radio_link":"(.+?)","user_login":"(.+?)","user_id":"(.+?)"}', content, re.IGNORECASE)
        
        for item in result:
            r = Radio()
            r.radio_cache = int(item[0])
            r.radio_name = str(item[1]).decode('unicode-escape')
            r.radio_img = '%s/covers/%s' % (url_static, item[2],)
            r.radio_description = str(item[3]).decode('unicode-escape')
            r.radio_pid = str(item[4]).decode('unicode-escape')
            r.radio_id = int(item[5])
            r.radio_link = str(item[6]).decode('unicode-escape')
            r.user_login = str(item[7]).decode('unicode-escape')
            r.user_id = int(item[8])
            self.radios.append(r)
        
    def getPopular(self, limit):
        content = getContent(url + self.app_path_popular % (limit),)
        result = re.findall('{"radio_id":"(.+?)","counter":"(.+?)","radio_cache":"(.+?)","radio_name":"(.+?)","radio_img":"(.+?)","radio_description":"(.+?)","radio_pid":"(.+?)","radio_link":"(.+?)","user_login":"(.+?)","user_id":"(.+?)"}', content, re.IGNORECASE)
        
        for item in result:
            r = Radio()
            r.radio_id = int(item[0])
            r.radio_cache = int(item[2])
            r.radio_name = str(item[3]).decode('unicode-escape')
            r.radio_img = '%s/covers/%s' % (url_static, item[4],)
            r.radio_description = str(item[5]).decode('unicode-escape')
            r.radio_pid = str(item[6]).decode('unicode-escape')
            r.radio_link = str(item[7]).decode('unicode-escape')
            r.user_login = str(item[8]).decode('unicode-escape')
            r.user_id = int(item[9])
            self.radios.append(r)

    def getAlphabetical(self):
        content = getContent(url + self.app_path_az)
        result = re.findall('{"radio_cache":"(.+?)","radio_name":"(.+?)","radio_img":"(.+?)","radio_description":"(.+?)","radio_pid":"(.+?)","radio_id":"(.+?)","radio_link":"(.+?)","user_login":"(.+?)","user_id":"(.+?)"}', content, re.IGNORECASE)
        
        for item in result:
            r = Radio()
            r.radio_cache = int(item[0])
            r.radio_name = str(item[1]).decode('unicode-escape')
            r.radio_img = '%s/covers/%s' % (url_static, item[2],)
            r.radio_description = str(item[3]).decode('unicode-escape')
            r.radio_pid = str(item[4]).decode('unicode-escape')
            r.radio_id = int(item[5])
            r.radio_link = str(item[6]).decode('unicode-escape')
            r.user_login = str(item[7]).decode('unicode-escape')
            r.user_id = int(item[8])
            self.radios.append(r)

class Style:
    radio_id = None
    radio_name = None
    radio_link = None
    radio_img = None
    
class Styles:
    #app_path = '/api/_cache_lastStyles?limit=&offset=0&format=json'
    app_path = '/api/_cache_getStyles?limit=0&offset=0&format=json'
    styles = [Style]
    styles.pop()
    
    def getStyles(self):
        content = getContent(url + self.app_path)
        result = re.findall('{"radio_id":"(.+?)","radio_name":"(.+?)","radio_link":"(.+?)","artists":(.+?)"radio_img":"(.+?)"}', content, re.IGNORECASE)
        
        for item in result:
            s = Style()
            s.radio_id = int(item[0])
            s.radio_name = str(item[1]).decode('unicode-escape')
            s.radio_link = item[2]
            s.radio_img = '%s/zcovers/_img/%s' % (url_static, item[4],)
            self.styles.append(s)

class Artist:
    radio_id = None
    radio_name = None
    radio_link = None
    artist_id = None
    radio_img = None

class Artists:
    app_path = '/api/_cache_getTheBestOf?limit=0&offset=0&format=json'
    artists = [Artist]
    artists.pop()
    
    def getArtists(self):
        content = getContent(url + self.app_path)
        result = re.findall('{"radio_id":"(.+?)","radio_name":"(.+?)","radio_link":"(.+?)","artist_id":(.+?)"radio_img":"(.+?)"}', content, re.IGNORECASE)
        
        for item in result:
            a = Artist()
            a.radio_id = int(item[0])
            a.radio_name = str(item[1]).decode('unicode-escape')
            a.radio_link = item[2]
            a.artist_id = item[3]
            a.radio_img = '%s/zcovers/_img/%s' % (url_static, item[4],)
            self.artists.append(a)

class Session:
    app_path = '/service/_getConfig&format=json&login=%s&password=%s'
    fileServer = None
    sessionId = None
    
    def getSession(self, login, password):
        content = getContent(url + self.app_path % (login, password,)) 
        result = re.findall('{"fileServer":"(.+?)","sessionid":"(.+?)"}', content, re.IGNORECASE)
        self.fileServer = result[0][0]
        self.sessionId = result[0][1]

url = 'http://fm.tuba.pl'
url_static = 'http://static.fm.tuba.pl'
url_images = 'http://images.tuba.fm'
login = 'norbsoft'
password = 'EehbpVFWzcNpfJxK'    
