﻿'''
Created on 11-08-2011

@author: Virus
'''

import xbmc
import xbmcgui
import xbmcplugin
import sys
import re
import urllib
import urllib2
import API

def createListing(level, sessionId, url):
    global thisPlugin
    global url_base

    if level == 0:
        session = API.Session()
        session.getSession(API.login, API.password)
        
        addFolder(1, session.sessionId, "Radio", '', '', '')
        addFolder(2, session.sessionId, "Gatunki", '', '', '')
        addFolder(3, session.sessionId, "Artyści", '', '', '')
        addFolder(5, session.sessionId, "Wasze radia", '', '', '')
        addFolder(4, session.sessionId, "Szukaj", '', '', '')

        xbmcplugin.endOfDirectory(thisPlugin)
        
    # Radio
    elif level == 1:
        stations = API.Stations()
        stations.getStations()
        stream = API.Stream()
        
        xbmcplugin.addSortMethod(thisPlugin, xbmcplugin.SORT_METHOD_TITLE)
        
        for station in stations.stations:
            addFolder(level + 100, sessionId, station.radio_name, station.radio_description, station.radio_img, stream.getStreamURL(station.radio_id)) 

        xbmcplugin.endOfDirectory(thisPlugin)
    
    # Styles
    elif level == 2:
        styles = API.Styles()
        styles.getStyles()
        
        xbmcplugin.addSortMethod(thisPlugin, xbmcplugin.SORT_METHOD_TITLE)
        
        for style in styles.styles:
            addFolder(1004, sessionId, style.radio_name, '', style.radio_img, str(style.radio_id)) 

        xbmcplugin.endOfDirectory(thisPlugin) 
        
    # Artists
    elif level == 3:
        artists = API.Artists()
        artists.getArtists()
        
        xbmcplugin.addSortMethod(thisPlugin, xbmcplugin.SORT_METHOD_TITLE)
        
        for artist in artists.artists:
            addFolder(1004, sessionId, artist.radio_name, '', artist.radio_img, str(artist.radio_id)) 

        xbmcplugin.endOfDirectory(thisPlugin) 

    # Search
    elif level == 4:
        kb = xbmc.Keyboard('', 'Czego chcesz słuchać?', False)
        kb.doModal()
        if not kb.isConfirmed():
            return
        keyword = kb.getText()
        type = None
        search = API.Search()
        search.doSearch(keyword, type)
            
        last_type = None   
        for item in search.results:
            if last_type != item.type:
              addFolder(-1, 'dummy', '--- ' + item.type_str + ' ---', '', '', 'dummy')
              last_type = item.type
            s = item.keyword
            if item.user_login != '':
                s = s + ' (' + item.user_login + ')'
            addFolder(item.type + 1000, sessionId, '    ' + s, '', '', str(item.id))

        xbmcplugin.endOfDirectory(thisPlugin)
        
    elif level == 5:
        session = API.Session()
        session.getSession(API.login, API.password)
        
        addFolder(200 + 1, session.sessionId, "Popularne", '', '', '')
        addFolder(200 + 2, session.sessionId, "Nowe", '', '', '')
        addFolder(200 + 3, session.sessionId, "A-Z", '', '', '')

        xbmcplugin.endOfDirectory(thisPlugin)
    
    # Search dispatch
    elif level == 1000 or level == 1001 or level == 1003 or level == 1004:
        p = API.Playlist()
        p.getPlaylist(sessionId, int(url), level - 1000)
        
        xbmcplugin.addSortMethod(thisPlugin, xbmcplugin.SORT_METHOD_TITLE)
        
        for item in p.playlist:
            addFolder(101, sessionId, item.title + ' (' + item.artist + ' | ' + item.album + ')', '', item.img, item.filename)
            
        xbmcplugin.endOfDirectory(thisPlugin)  
        
    elif level == 1002:
        stream = API.Stream()
        stream.getStreamURL(int(url))
        p = xbmc.Player()
        p.play(url)

    elif level == 101:
        xbmc.Player().play(str(url))

    elif level == 102:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
    
        p = API.Playlist()
        p.getPlaylist(sessionId, int(url), 4)
        
        for item in p.playlist:
            playlist.add(item.filename)
            
        xbmc.Player().play(playlist)
        
    elif level == 201 or level == 202 or level == 203:
        radios = API.Radios()
        
        if level == 201:
            radios.getPopular(100)
        elif level == 202:
            radios.getLatest(100)
        elif level == 203:
            radios.getAlphabetical()
        
        for radio in radios.radios:
            addFolder(1000, sessionId, radio.radio_name, radio.radio_description, radio.radio_img, str(radio.radio_id)) 

        xbmcplugin.endOfDirectory(thisPlugin)
        
    elif level == -1:
        xbmcplugin.endOfDirectory(thisPlugin)
        
    else:
        addFolder(level, sessionId, 'Unknown level: %d' % (level,), '', '', '')
        xbmcplugin.endOfDirectory(thisPlugin)
        print 'Unknown level: %d' % (level,)

def addFolder(level, sessionId, caption, desc, icon, link):
    global thisPlugin

    if link == '':
        link = 'dummy'

    url = sys.argv[0] + '?level=' + urllib.quote_plus(str(level)) + '&sessionId=' + urllib.quote_plus(sessionId) + '&url=' + urllib.quote_plus(link) 
    listItem = xbmcgui.ListItem(label = caption, label2 = desc, iconImage = icon)
    if level != 101:
        xbmcplugin.addDirectoryItem(thisPlugin, url, listItem, True)
    else:
        xbmcplugin.addDirectoryItem(thisPlugin, url, listItem, False)

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]

    return param

thisPlugin = int(sys.argv[1])
level = 0
sessionId = None
url = 'dummy'
params=get_params()

try:
    level = int(urllib.unquote_plus(params['level']))
except:
    pass

try:
    url = urllib.unquote_plus(params['url'])
except:
    pass

try:
    sessionId = urllib.unquote_plus(params['sessionId'])
except:
    pass

createListing(level, sessionId, url)
