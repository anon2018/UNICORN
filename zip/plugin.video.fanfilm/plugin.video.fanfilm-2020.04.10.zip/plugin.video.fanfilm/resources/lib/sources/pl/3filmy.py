# -*- coding: utf-8 -*-

'''
    Covenant Add-on
    Copyright (C) 2018 CherryTeam

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re

from resources.lib.libraries import client, cleantitle, control, cache

try:
    import HTMLParser
    from HTMLParser import HTMLParser
except:
    from html.parser import HTMLParser
try:
    import urlparse
except:
    import urllib.parse as urlparse
try:
    import urllib2
except:
    import urllib.request as urllib2


class source:
    def __init__(self):

        self.priority = 1
        self.language = ['pl']
        self.domains = ['3filmy.com']
        self.base_link = 'https://3filmy.com'
        self.search_link = 'https://3filmy.com/ajax/search?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, year)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return tvshowtitle, localtvshowtitle, year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        return self.search_ep(url, season, episode)

    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def fix_year(self, title, year):
        if title == "Gra o tron":
            return "2011"
        if title == "Family Guy":
            return "1999"
        else:
            return year

    def search_ep(self, tvshow, season, episode):
        try:
            title = tvshow[0]
            localtitle = tvshow[1]
            year = self.fix_year(localtitle, tvshow[2])
            year = self.fix_year(title, year)
            titles = []
            titles.append(cleantitle.normalize(cleantitle.getsearch(title)))
            titles.append(cleantitle.normalize(cleantitle.getsearch(localtitle)))

            season_episode = "S%02dE%02d" % (int(season), int(episode))

            for title in titles:
                result = client.request(self.search_link % title.replace(" ", "%20"))

                result = json.loads(result)
                for item in result:
                    try:
                        rok = item['d']
                        link = item['link'].replace("\/", "/")
                        tytul = item['t']
                        words = title.lower().split(" ")
                        if self.contains_all_words(cleantitle.normalize(cleantitle.getsearch(tytul).lower()), words) and year in rok:
                            link = self.base_link + link
                            result2 = client.request(link)
                            result2 = client.parseDOM(result2, 'div', attrs={'class': "se-c"})
                            test = client.parseDOM(result2, 'li', ret='data-id')
                            result2 = client.parseDOM(result2, 'li')
                            for item2, id in zip(result2, test):
                                if season_episode in item2:
                                    return link + client.parseDOM(item2, 'a', ret='href')[0] + "|" + id
                    except Exception as e:
                        continue
            return
        except Exception as e:
            print(e)
            return

    def search(self, title, localtitle, year):
        try:
            titles = []
            titles.append(cleantitle.normalize(cleantitle.getsearch(title)))
            titles.append(cleantitle.normalize(cleantitle.getsearch(localtitle)))

            for title in titles:
                result = client.request(self.search_link % title)

                result = json.loads(result)
                for item in result:
                    try:
                        rok = item['d']
                        link = item['link'].replace("\/", "/")
                        tytul = item['t']
                        words = title.lower().split(" ")
                        if self.contains_all_words(cleantitle.normalize(cleantitle.getsearch(tytul)), words) and year in rok:
                            return self.base_link + link
                    except:
                        continue
            return
        except Exception as e:
            print(e)
            return

    def get_lang_by_type(self, lang_type):
        if "dubbing" in lang_type.lower():
            if "kino" in lang_type.lower():
                return 'pl', 'Dubbing Kino'
            return 'pl', 'Dubbing'
        elif 'napisy pl' in lang_type.lower():
            return 'pl', 'Napisy PL'
        elif 'napisy en' in lang_type.lower():
            return 'en', 'Napisy ENG'
        elif 'napisy' in lang_type.lower():
            return 'pl', 'Napisy'
        elif 'lektor pl' in lang_type.lower():
            return 'pl', 'Lektor'
        elif 'lektor' in lang_type.lower():
            return 'pl', 'Lektor'
        elif 'polski' in lang_type.lower():
            return 'pl', None
        elif 'pl' in lang_type.lower():
            return 'pl', None
        return 'en', None

    def sources(self, url, hostDict, hostprDict):
        login()
        try:
            cookies = cache.cache_get('3filmy_cookie')['value']
        except:
            cookies = ''
        sources = []
        data_id = ''
        tvshow = False
        try:
            if url == None: return sources
            try:
                data_id = url.split("|")[1]
            except:
                pass
            url = url.split("|")[0]
            result = client.request(url)
            data_hash = re.findall("data-hash=\"(.*?)\"", result)[0]
            if not data_id:
                data_id = url.split(".html")[0].split("-")[-1]
                test = json.loads(client.request("https://3filmy.com/ajax/video.details", post={'id': data_id, 'hash': data_hash}, cookie=cookies))
            else:
                tvshow = True
                test = json.loads(client.request("https://3filmy.com/ajax/video.details", post={'id': data_id, 'hash': data_hash, 'ep': "true"}, cookie=cookies))
            from urllib import unquote
            opts = [test['ch']]
            for opt in test['opts']:
                opts.append(opt)
            for opt in opts:
                if not tvshow:
                    test = json.loads(client.request("https://3filmy.com/ajax/video.details", post={'id': data_id, 'hash': data_hash, 'd': opt[0]}, cookie=cookies))
                else:
                    test = json.loads(client.request("https://3filmy.com/ajax/video.details", post={'id': data_id, 'hash': data_hash, 'd': opt[0], 'ep': "true"}, cookie=cookies))
                for quality in test['q_avb']:
                    if not tvshow:
                        test = json.loads(client.request("https://3filmy.com/ajax/video.details", post={'id': data_id, 'hash': data_hash, 'q': quality, 'd': opt[0]}, cookie=cookies))
                    else:
                        test = json.loads(client.request("https://3filmy.com/ajax/video.details", post={'id': data_id, 'hash': data_hash, 'q': quality, 'd': opt[0], 'ep': "true"}, cookie=cookies))
                    url = unquote(test['link']).decode('utf8')
                    url = do_xor("5d", url)
                    lang, info = self.get_lang_by_type(opt[1])
                    if int(quality) >= 720:
                        sources.append({'source': "3Filmy", 'quality': 'HD', 'language': lang, 'url': url, 'info': info, 'direct': True, 'debridonly': False})
                    else:
                        sources.append({'source': "3Filmy", 'quality': 'SD', 'language': lang, 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return sources

    def resolve(self, url):
        return url


from itertools import cycle


def do_xor(key, str):
    key = ''.join(key.split()[::-1]).decode('hex')
    return ''.join([chr(ord(a) ^ ord(b)) for a, b in zip(str, cycle(key))])


def login():
    import requests
    sess = requests.Session()

    pwd = control.setting('3filmy.password')
    usr = control.setting('3filmy.username')

    if not usr or not pwd:
        usr = "3filmyacc"
        pwd = "3filmy_acc"

    headers = {
        'Host': '3filmy.com',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'upgrade-insecure-requests': '1',
        'te': 'trailers',
    }
    if pwd and usr:

        sess.get('https://3filmy.com', headers=headers, verify=False)

        headers = {
            'Host': '3filmy.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
            'accept': '*/*',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'x-requested-with': 'XMLHttpRequest',
            'origin': 'https://3filmy.com',
            'dnt': '1',
            'referer': 'https://3filmy.com/seriale/',
            'te': 'trailers',
        }

        data = 'a=signin-modal'

        response = sess.post('https://3filmy.com/ajax/modal', headers=headers, data=data, verify=False).content

        expir, has = re.findall("""expires['"]\s*value=['"](.+?)['"].+?hash['"]\s*value=['"](.+?)['"]""", response)[0]
        headers = {
            'Host': '3filmy.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'x-requested-with': 'XMLHttpRequest',
            'origin': 'https://3filmy.com',
            'referer': 'https://3filmy.com/seriale/',
            'te': 'trailers',
        }

        data = 'expires=%s&hash=%s&username=%s&password=%s&remember_me=ON' % (expir, has, usr, pwd)

        response = sess.post('https://3filmy.com/ajax/login', headers=headers, data=data, verify=False)

        content = response.json()
        if content.has_key('success'):
            log = True
        else:
            log = False

    else:
        sess.get('https://3filmy.com/', headers=headers, verify=False)
        log = False
    sc = ''.join(['%s=%s;' % (c.name, c.value) for c in sess.cookies])
    cache.cache_insert('3filmy_cookie', sc)
    return log