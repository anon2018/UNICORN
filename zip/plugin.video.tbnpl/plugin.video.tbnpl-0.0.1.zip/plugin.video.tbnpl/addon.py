import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
from CommonFunctions import stripTags
from CommonFunctions import replaceHTMLCodes


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.tbnpl')
mybtn_user = ''


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(url, name, image, folder, mode):
    list_item = xbmcgui.ListItem(label=name)

    if folder:
        list_item.setProperty("IsPlayable", 'false')
    else:
        list_item.setProperty("IsPlayable", 'true')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': mode, 'url': url, 'token': mybtn_user}),
        listitem=list_item,
        isFolder=folder
    )


def login():
    global mybtn_user

    username = addon.getSetting('username')
    password = addon.getSetting('password')
    url = 'https://www.tbnpolska.tv/mytbn/go/rt-ondemand'

    if username and password:
        response = requests.post(
            url,
            verify=False,
            allow_redirects=False,
            data={'form': 'login', 'username': username, 'password': password}
        )
        mybtn_user = response.cookies['MYTBNPL_USER']
    else:
        xbmcgui.Dialog().ok('TBN', 'Podaj dane logowania w ustawieniach wtyczki.')
        xbmcaddon.Addon(id='plugin.video.tbnpl').openSettings('Konto')
        xbmc.executebuiltin("Container.Refresh")


def home():
    login()

    url = 'https://vod.tbnpolska.tv/wszystkie'
    r = requests.get(
        url,
        verify=False,
        cookies={'MYTBNPL_USER': mybtn_user}
    )
    playlist = parseDOM(r.content, "div", attrs={"class": "playlist-content--stacked clearfix"})
    urls = parseDOM(playlist, "a", ret="href")
    img = parseDOM(playlist, "img", ret="src")

    for index, path in enumerate(urls):
        title = path.replace('katalog/', '').replace('-', ' ').title()
        image = 'http://www.tbnpolska.tv' + replaceHTMLCodes(img[index]).split('src=')[1]
        url = 'https://vod.tbnpolska.tv/' + path
        add_item(url, title, image, True, "details")
    xbmcplugin.endOfDirectory(addon_handle)


def details():
    global mybtn_user
    url = params.get('url', None)
    mybtn_user = params.get('token', None)

    r = requests.get(
        url,
        verify=False,
        cookies={'MYTBNPL_USER': mybtn_user}
    )

    list = parseDOM(r.content, 'ul', attrs={'class': 'series-list'})
    items = parseDOM(r.content, 'li')
    image = parseDOM(r.content, 'meta', attrs={'property': 'og:image'}, ret='content')[0]

    if len(list):
        active = parseDOM(r.content, 'li', attrs={'class': 'active'})
        items = [active] + items
        for item in items:
            url = 'https://vod.tbnpolska.tv/' + parseDOM(item, 'a', ret="href")[0].encode('utf-8')
            title = stripTags(parseDOM(item, 'a')[0].encode('utf-8'))
            add_item(url, title, image, False, 'play')
    else:
        title = parseDOM(r.content, 'div', attrs={'class': 'fsPlayer--title'})[0].encode('utf-8')
        add_item(url, title, image, False, 'play')

    xbmcplugin.endOfDirectory(addon_handle)


def play():
    url = params.get('url', None)
    token = params.get('token', None)
    print(url)
    r = requests.get(
        url,
        verify=False,
        cookies={'MYTBNPL_USER': token}
    )
    print(r.content)
    stream_url = parseDOM(r.content, 'source', ret='src')[0]
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'details':
        details()
    elif mode == 'play':
        play()
