# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.monster.tv')
resources = xbmc.translatePath(addon.getAddonInfo('path') + '/resources/')

movies_url = 'https://joemonster.org/api_v1/movies'

headers = {
    'Host': 'joemonster.org',
    'User-Agent': 'okhttp/3.6.0',
    'Accept-Encoding': 'gzip',
    'Connection': 'Keep-Alive'
}


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, image, is_folder, is_playble, payload, plot=''):
    list_item = xbmcgui.ListItem(label=name)

    if is_playble:
        list_item.setProperty("IsPlayable", 'true')
    else:
        list_item.setProperty("IsPlayable", 'false')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name, 'plot': plot})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=is_folder
    )


def play():
    content_url = params.get('content_url', None)
    file_type = params.get('file_type', '')

    if file_type == 'youtube':
        content_url = 'plugin://plugin.video.youtube/play/?video_id=' + content_url.split('/')[-1]

    play_item = xbmcgui.ListItem(path=content_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


def home():
    offset = int(params.get('offset', '0'))

    data = {'show_comments': 'off',
            'order': 'DESC',
            'short_text': 'on',
            'offset': offset,
            'limit': 100}
    response = requests.get(
        movies_url,
        params=data,
        verify=False,
        headers=headers
    ).json()

    if offset > 0:
        add_item('<< POPRZEDNIA STRONA', resources + 'transparent.png', False, False,
                 {'mode': 'prev_page', 'last_offset': offset})

    for item in response.get('movies', []):
        if item.get('access_status', '') != 'unsubscribed':
            title = item.get('title', '')
            icon = item.get('thumb_url', '')
            content_url = item.get('content_url', '')
            plot = item.get('text', '')
            file_type = item.get('file_type', '')
            add_item(title, icon, False, True, {'mode': 'play', 'content_url': content_url, 'file_type': file_type}, plot)

    add_item('NASTĘPNA STRONA >>', resources+'transparent.png', False, False, {'mode': 'next_page', 'last_offset': offset})
    xbmcplugin.endOfDirectory(addon_handle)


def next_page():
    last_offset = int(params.get('last_offset', '0'))
    xbmc.executebuiltin('Container.Update("%s",replace)' % build_url({'offset': last_offset + 100}))


def prev_page():
    last_offset = int(params.get('last_offset', '0'))
    xbmc.executebuiltin('Container.Update("%s",replace)' % build_url({'offset': last_offset - 100}))


def route():
    mode = params.get('mode', None)

    if not mode:
        home()
    elif mode == 'play':
        play()
    elif mode == 'next_page':
        next_page()
    elif mode == 'prev_page':
        prev_page()


if __name__ == '__main__':
    route()
