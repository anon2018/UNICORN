# -*- coding: UTF-8 -*-
import os
import time
import threading
import re

import xbmc
import xbmcaddon
import xbmcvfs
from ptw.libraries import client
from ptw.libraries import cleantitle
from future.moves.html.parser import HTMLParser

try:
    import sqlite3
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

addonInfo = xbmcaddon.Addon().getAddonInfo
dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
xbmcvfs.mkdir(dataPath)
scraperFile = os.path.join(dataPath, 'cache.db')

def remove_tags(text):
    TAG_RE = re.compile(r'<[^>]+>')
    return TAG_RE.sub('', text)

def scraper_check(url='', tvdb=False):
    try:
        name = url.split('/')[-1]
        name = cleantitle.normalize(cleantitle.getsearch(name))
        db = database.connect(scraperFile, detect_types=sqlite3.PARSE_DECLTYPES,
                                            cached_statements=20000)
        db.text_factory = str
        cur = db.cursor()
        cur.execute('PRAGMA foreign_keys = ON')
        cur.execute('PRAGMA synchronous = OFF')
        cur.execute('PRAGMA journal_mode = OFF')
        cur.execute("PRAGMA page_size = 16384")
        cur.execute("PRAGMA cache_size = 64000")
        cur.execute("PRAGMA temp_store = MEMORY")
        cur.execute("PRAGMA locking_mode = NORMAL")
        cur.execute("PRAGMA count_changes = OFF")
        cur.execute("PRAGMA optimize")
        cur.execute("CREATE TABLE IF NOT EXISTS AnimeOdcinki (name TEXT unique, poster TEXT, plot  TEXT, banner  TEXT, fanart  TEXT, imdbid TEXT)")
        db.commit()
        cur.execute("SELECT * FROM AnimeOdcinki WHERE name=?", (name,))
        items = cur.fetchall()
        for row in items:
            name = row[0]
            image = row[1]
            plot = row[2]
            banner = row[3]
            fanart = row[4]
            imdbid = row[5]
            if name:
                return name, image, plot, banner, fanart, imdbid, None
            else:
                return '', '', '', '', '', '', None
        else:
            if tvdb:
                t = threading.Thread(target=scraperTVDB_add, args=(name,))
                return '', '', '', '', '', '', t
            else:
                t = threading.Thread(target=scraper_add, args=(url, name,))
                return '', '', '', '', '', '', t
    except:
        return '', '', '', '', '', '', None
    finally:
        db.close()


def scraper_add(url, name):
    try:
        r = client.request(url)
        result = client.parseDOM(r, 'div', attrs={'class': "field-item even"})
        h = HTMLParser()
        result = h.unescape(result)
        poster = str(client.parseDOM(result[0], 'img', ret='src')[0])
        plot = h.unescape(remove_tags(client.parseDOM(result[1], 'p')[1]))
        while True:
            time.sleep(1)
            db = database.connect(scraperFile)
            cur = db.cursor()
            try:
                cur.execute("SELECT count(*) FROM AnimeOdcinki WHERE name = ?", (name,))
                data = cur.fetchone()[0]
                if not data:
                    print('There is no component named %s' % name)
                    cur.execute("INSERT INTO AnimeOdcinki (name, poster, plot, banner, fanart, imdbid) VALUES(?,?,?,?,?,?)",
                                (name, poster, plot, '', '', ''))
                    db.commit()
                    break
                else:
                    print('Component %s found in rows' % (name))
                    break
            except sqlite3.OperationalError as e:
                print(e)
                continue
    except Exception as e:
        raise e
    finally:
        db.close()

def scraperTVDB_add(name):
    try:
        time.sleep(15)
        db = database.connect(scraperFile)
        cur = db.cursor()

        tvdb_search_all = "https://www.thetvdb.com/api/GetSeries.php?seriesname=%s&language=all"
        tvdb_search_pl = "https://www.thetvdb.com/api/GetSeries.php?seriesname=%s&language=pl"
        banner_url = "https://www.thetvdb.com/banners/graphical/%s-g.jpg"
        fanart_url = "https://www.thetvdb.com/banners/fanart/original/%s-1.jpg"
        poster_url = "https://www.thetvdb.com/banners/posters/%s-1.jpg"
        r = client.request(tvdb_search_pl % name.replace(' ', '%20'))
        if not r:
            r = client.request(tvdb_search_all % name.replace(' ', '%20'))

        id = re.findall("""<seriesid>(.*)</seriesid>""", r)[0]
        fanart = fanart_url % id
        banner = banner_url % id
        poster = poster_url % id
        plot = re.findall("""<Overview>(.*)</Overview>""", r)[0]
        imdbid = re.findall("""<IMDB_ID>(.*)</IMDB_ID>""", r)[0]

        start_time = time.time()
        delta_time = 0
        while delta_time < 120:
            delta_time = time.time() - start_time
            time.sleep(0.05)
            try:
                cur.execute("SELECT count(*) FROM AnimeOdcinki WHERE name = ?", (name,))
                data = cur.fetchone()[0]
                if not data:
                    print('There is no component named %s' % name)
                    cur.execute("INSERT INTO AnimeOdcinki (name, poster, plot, banner, fanart, imdbid) VALUES(?,?,?,?,?,?)",
                                (name, poster, plot, banner, fanart, imdbid))
                    db.commit()
                    break
                else:
                    print('Component %s found in rows' % (name))
                    break
            except sqlite3.OperationalError as e:
                print(e)
                continue
    except Exception as e:
        raise e
    finally:
        db.close()
