# -*- coding: UTF-8 -*-
import json
import os
import sys
import scraper
import time
import threading

import xbmc
import xbmcaddon
import xbmcplugin
from future.moves.html.parser import HTMLParser
from ptw.libraries import addon_utils as addon
from ptw.libraries import client

__settings__ = xbmcaddon.Addon(id="plugin.video.anime-odcinki")
addonPath = __settings__.getAddonInfo('path')
sys.path.append(os.path.join(addonPath, 'crypto'))

from keyedHash.evp import EVP_BytesToKey
from cipher.aes_cbc import AES_CBC
from binascii import a2b_hex, a2b_base64
from hashlib import md5


# =########################################################################################################=#
#                                                   MENU                                                   #
# =########################################################################################################=#

def CATEGORIES():
    addon.addDir("Wyszukiwarka", '', mode=1)

    addon.addDir("[Anime] Alfabetycznie", '', mode=10)
    addon.addDir("[Anime] Wszystkie", 'https://anime-odcinki.pl/anime', mode=20)
    addon.addDir("[Anime] Emitowane", 'https://anime-odcinki.pl/anime', mode=30)

    addon.addDir("[Filmy] Alfabetycznie", '', mode=10)
    addon.addDir("[Filmy] Wszystkie", 'https://anime-odcinki.pl/filmy', mode=20)


############################################################################################################
# =########################################################################################################=#
#                                                 FUNCTIONS                                                #
# =########################################################################################################=#

def Wyszukiwanie():
    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()
    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()
        url = "https://anime-odcinki.pl/szukaj/%s" % search.replace(" ", "+")
        r = client.request(url)
        h = HTMLParser()
        r = h.unescape(r)

        result = client.parseDOM(r, 'li', attrs={'class': 'search-result'})
        threads = []
        for item in result:
            try:
                nazwa = str(client.parseDOM(item, 'a')[0])
                link = str(client.parseDOM(item, 'a', ret='href')[0])
                name, poster, plot, banner, fanart, imdbid, thread = scraper.scraper_check(link)
                if thread:
                    threads.append(thread)
                addon.addDir(nazwa, link, mode=6, thumb=poster, poster=poster, plot=plot, fanart=fanart)
            except:
                continue
        t = threading.Thread(target=scrape_info, args=(threads,))
        t.start()
    else:
        CATEGORIES()


def Alfabet():
    name = params.get('name')
    Alfabet = list(map(chr, range(65, 91)))
    for litera in Alfabet:
        if 'Anime' in name:
            addon.addDir(str(litera), 'https://anime-odcinki.pl/anime', mode=20)
        else:
            addon.addDir(str(litera), 'https://anime-odcinki.pl/filmy', mode=20)


def Wszystkie(literka='', url=''):
    if not url:
        url = params['url']
    name = params.get('name')

    if len(name) <= 1:
        literka = str(name)
    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'tr', attrs={'class': 'list-item'})
    threads = []
    for item in result:
        nazwa = str(client.parseDOM(item, 'a')[0])
        link = str(client.parseDOM(item, 'a', ret='href')[0])

        if literka:
            if not nazwa.lower().startswith(literka.lower()):
                continue
            else:
                name, poster, plot, banner, fanart, imdbid, thread = scraper.scraper_check(link)
                if thread:
                    threads.append(thread)
                addon.addDir(nazwa, link, mode=6, thumb=poster, poster=poster, plot=plot)
        else:
            name, poster, plot, banner, fanart, imdbid, thread = scraper.scraper_check(link)
            if thread:
                threads.append(thread)
            addon.addDir(nazwa, link, mode=6, thumb=poster, poster=poster, plot=plot)
    t = threading.Thread(target=scrape_info, args=(threads,))
    t.start()


def Emitowane():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'item-list'})
    result = client.parseDOM(result, 'li')
    threads = []
    for item in result:
        try:
            nazwa = str(client.parseDOM(item, 'a')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            name, poster, plot, banner, fanart, imdbid, thread = scraper.scraper_check(link)
            if thread:
                threads.append(thread)
            addon.addDir(nazwa, link, mode=6, thumb=poster, poster=poster, plot=plot, fanart=fanart)
        except:
            continue
    t = threading.Thread(target=scrape_info, args=(threads,))
    t.start()


def ListowaniOdcinkow():
    url = params['url']
    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'li', attrs={'class': 'lista_odc_tytul_pozycja'})

    for item in result:
        link = client.parseDOM(item, 'a', ret='href')[0]
        nazwa = client.parseDOM(item, 'a')[0]
        if nazwa and link:
            addon.addLink(str(nazwa), str(link), mode=5)


def WysiwetlanieLinkow():
    url = params['url']
    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    import re
    result = re.findall(r"""video-player-mode.*?data-hash='(.*?)'>\s(.*?)\s<""", r)

    items = []
    for item in result:
        try:
            link = encryptPlayerUrl(item[0])
            nazwa = item[1]
            if nazwa and link:
                items.append({'href': link, 'name': nazwa})
        except:
            continue
    addon.SourceSelect(items)

def scrape_info(threads):
    while True:
        if xbmc.Player().isPlaying():
            for thread in threads:
                while True:
                    if xbmc.Player().isPlaying() and threading.active_count() < 20:
                        thread.start()
                        break
                    else:
                        time.sleep(2)
        else:
            time.sleep(2)

def encryptPlayerUrl(data):
    decrypted = ''
    try:
        data = byteify(json.loads(data))
        salt = a2b_hex(data["v"])
        key, iv = EVP_BytesToKey(md5, "s05z9Gpd=syG^7{", salt, 32, 16, 1)
        if iv != a2b_hex(data.get('b', '')):
            print("_encryptPlayerUrl IV mismatched")
        else:
            kSize = len(key)
            alg = AES_CBC(key, keySize=kSize)
            decrypted = alg.decrypt(a2b_base64(data["a"]), iv=iv)
            decrypted = decrypted.split('\x00')[0]
        decrypted = "%s" % json.loads(decrypted).encode('utf-8')
    except:
        decrypted = ''
    return decrypted




############################################################################################################
# =########################################################################################################=#
#                                               GET PARAMS                                                 #
# =########################################################################################################=#

params = addon.get_params()
url = params.get('url')
name = params.get('name')
try:
    mode = int(params.get('mode'))
except:
    mode = None
iconimage = params.get('iconimage')


def byteify(input):
    if isinstance(input, dict):
        return dict([(byteify(key), byteify(value)) for key, value in input.iteritems()])
    elif isinstance(input, list):
        return [byteify(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input


###############################################################################################################
# =###########################################################################################################=#
#                                                   MODES                                                     #
# =###########################################################################################################=#

if mode == None:
    CATEGORIES()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 1:
    Wyszukiwanie()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 10:
    Alfabet()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 20:
    Wszystkie()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 30:
    Emitowane()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 6:
    ListowaniOdcinkow()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 5:
    WysiwetlanieLinkow()
###################################################################################
