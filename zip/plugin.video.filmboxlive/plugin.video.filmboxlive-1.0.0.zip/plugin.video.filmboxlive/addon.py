# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import inputstreamhelper

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmboxlive')
resources = xbmc.translatePath(addon.getAddonInfo('path') + '/resources/')

main_url = 'http://filmboxliveapp.net/cmsendpoint.json'
api_url = 'https://api.invideous.com'
country_check_url = 'http://mip.filmboxlive.com/CountryService.svc/CheckCountry'
ticket_url = 'http://key.erstream.com/api/ticket/create'

username = addon.getSetting('username')
password = addon.getSetting('password')
sessionid = params.get('sessionid', '')
userid = params.get('userid', '')

repeated = False

MUA = 'Dalvik/2.1.0 (Linux; U; Android 5.1; Dalvik/2.1.0 (Linux; U; Android 8.0.0; Nexus 5X Build/OPP3.170518.006) Build/LMY47D)'

publisher_id = '5842'
package_id = '12'
ticket_key = '5dd3e0da5423de187d9938a45e2c81b7'


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, image, is_folder, is_playble, payload, info_labels={}):
    list_item = xbmcgui.ListItem(label=name)

    if is_playble:
        list_item.setProperty("IsPlayable", 'true')
    else:
        list_item.setProperty("IsPlayable", 'false')

    info_labels['title'] = name
    info_labels['sorttitle'] = name

    payload['sessionid'] = sessionid
    payload['userid'] = userid

    list_item.setInfo(type='video', infoLabels=info_labels)
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=is_folder
    )


def add_folder(name, image, payload):
    add_item(name, image, True, False, payload)


def play():

    url = params.get('url', None)
    if 'm3u8' not in url and 'mp4' not in url:
        final_url = requests.get(
            url,
            verify=False,
            allow_redirects=False,
            headers={'User-Agent': MUA, 'Referer': api_url}
        ).headers.get('Location', None)
    else:
        final_url = url

    country_response = requests.get(
        country_check_url,
        verify=False,
        headers={'User-Agent': MUA}
    ).json()

    ip = country_response.get('ClientIP', None)
    if final_url:
        data = {
            'url': final_url,
            'clientip': ip,
            'key': ticket_key,
            'userid': userid,
            'device': 'Google',
            'domain': 'Filmbox'
        }

        response = requests.get(
            ticket_url,
            params=data,
            verify=False,
            headers={'User-Agent': MUA, 'Referer': url}
        ).text

        manifest = final_url + '?' + response + '&device=Google&userID='+userid+'&domain=filmbox'
        if 'mp4' in final_url:
            play_item = xbmcgui.ListItem(path=manifest)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
            return

        is_helper = inputstreamhelper.Helper('hls')
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=manifest)
            play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

    else:
        print('no final')


def login():
    global sessionid
    global userid
    global repeated

    username = addon.getSetting('username')
    password = addon.getSetting('password')

    if not username or not password:
        xbmcgui.Dialog().ok('Filmbox Live', 'Podaj dane logowania w ustawieniach wtyczki.')
        return False

    data = {
        'username': username,
        'password': password,
        'platform': 'mobile'
    }

    response = requests.post(
        api_url + '/plugin/login',
        params=data,
        verify=False,
        headers={'User-Agent': MUA}
    ).json()

    user_info = response.get('response', {}).get('result', {}).get('user_info', {})
    if user_info.get('guest', '1') == '0':
        sessionid = user_info.get('session_id', None)
        userid = user_info.get('id', None)
        return True
    else:
        if not repeated:
            repeated = True
            return login()
        else:
            sessionid = ''
            userid = ''
            xbmcgui.Dialog().ok('Nieudane logowanie',
                                'Sprawdz login i hasło w ustawieniach wtyczki oraz waznosc abonamentu.')
        return False


def list(search_phrase=None):
    search_name = params.get('searchName', None)
    page = params.get('page', '1')

    id = params.get('id', None)
    season = params.get('season', None)
    live = params.get('live', None)

    data = {
        'publisher_id': publisher_id,
        'package_id': package_id,
        'records_per_page': '50'
    }
    if search_phrase:
        data['custom_filter_by_title'] = search_phrase
    elif search_name:
        xbmcplugin.setContent(addon_handle, 'movies')
        data['custom_filter_by_genre'] = search_name
        data['custom_order_by_order_priority'] = 'asc'
        data['page'] = page
    elif live == '1':
        xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)
        data['filter_by_live'] = '1'
    else:
        xbmcplugin.setContent(addon_handle, 'episodes')
        data['custom_filter_by_series_id'] = id
        data['custom_filter_by_season_num'] = season
        data['custom_order_by_episode_code'] = 'asc'
        data['page'] = page

    response = requests.get(
        api_url + '/plugin/get_package_videos',
        params=data,
        verify=False,
        headers={'User-Agent': MUA}
    ).json()

    videos = response.get('response', {}).get('result', {}).get('videos', [])
    for video in videos:
        id = video.get('id', None)
        attributes = video.get('custom_attributes', {})
        title = video.get('title', '').encode('utf-8', 'ignore')
        image = attributes.get('promoImage', '')
        genre = attributes.get('genres_pl', '').encode('utf-8', 'ignore')

        info_labels = prepare_info_labels(attributes)

        if live == '1':
            url = attributes.get('samsung_url', None)
        elif genre == 'ULTRA1':
            url = attributes.get('samsung_source_url', None)
        else:
            url = attributes.get('ios_source_url', None)

        seasons = attributes.get('available_season', None)

        if seasons:
            mode = 'seasons'
            playble = False
            folder = True
        else:
            mode = 'play'
            playble = True
            folder = False

        add_item(title, image, folder, playble, {'mode': mode, 'url': url, 'seasons': seasons, 'id': id}, info_labels)

    total = response.get('response', {}).get('result', {}).get('total_pages', 0)
    next = int(page) + 1
    if next <= total:
        add_folder('[B]następna strona >>[/B]', resources+'transparent.png', {'mode': 'list', 'page': str(next), 'searchName': search_name})

    if search_phrase and len(videos) == 0:
        add_folder('Wróć - nie ma wyników pasujących do wyszukiwania', resources + 'back.png', {})

    xbmcplugin.endOfDirectory(addon_handle)


def prepare_info_labels(attributes):
    genres = attributes.get('genres_pl', '').encode('utf-8', 'ignore').split(',')
    genres = map(lambda x: x.replace('1', '').replace('2', '').replace('3', ''), genres)

    components = attributes.get('duration', '').split(":")
    duration = ''
    if len(components) > 1:
        duration = (int(components[0]) * 3600) + (int(components[1]) * 60)
    if len(components) > 2:
        duration = duration + int(components[0])

    return {
        'plot': attributes.get('description_pl', '').encode('utf-8', 'ignore'),
        'duration': duration,
        'genre': genres,
        'country': attributes.get('country', '').encode('utf-8', 'ignore').split(','),
        'year': attributes.get('year_of_production', '').encode('utf-8', 'ignore'),
        'cast': attributes.get('cast', '').encode('utf-8', 'ignore').split(','),
        'director': attributes.get('director', '').encode('utf-8', 'ignore').split(','),
        'mpaa': attributes.get('age_raiting', '').encode('utf-8', 'ignore'),
        'originaltitle': attributes.get('title_en', '').encode('utf-8', 'ignore'),
    }


def seasons():
    xbmcplugin.setContent(int(sys.argv[1]), 'season')
    id = params.get('id', None)
    seasons = params.get('seasons', '1').split(',')

    for season in seasons:
        add_folder('Sezon ' + season, '', {'mode': 'list', 'id': id, 'season': season})

    xbmcplugin.endOfDirectory(addon_handle)


def movies():
    xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    response = requests.get(
        main_url,
        verify=False,
        headers={'User-Agent': MUA}
    ).json()

    cms_endpoint = response.get('cmsendpoint', None) + '/getAllCategories'

    categories = requests.get(
        cms_endpoint,
        params={'countryName': 'pl'},
        verify=False,
        headers={'User-Agent': MUA}
    ).json()

    for category in categories:
        name = category.get('name', '')
        search_name = category.get('searchName', '')
        add_item(name, '', True, False, {'mode': 'list', 'searchName': search_name})

    add_item('UHD', '', True, False, {'mode': 'list', 'searchName': 'ULTRA1'})
    xbmcplugin.endOfDirectory(addon_handle)


def search():
    keyb = xbmc.Keyboard('', 'Wyszukiwanie filmów, seriali...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        if keyb.getText() == '':
            add_folder('Wróć - nie ma wyników pasujących do wyszukiwania', resources + 'back.png', {})
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            list(keyb.getText())


def home():
    if not userid:
        if not login():
            return
    add_folder('Wyszukiwanie filmów, seriali...', resources + 'search.png', {'mode': 'search'})
    add_folder('Filmy', '', {'mode': 'movies'})
    add_folder('Seriale', '', {'mode': 'list', 'searchName': 'SERIES1'})
    add_folder('Kanały TV', '', {'mode': 'list', 'live': '1'})
    xbmcplugin.endOfDirectory(addon_handle)


if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'movies':
        movies()
    elif mode == 'seasons':
        seasons()
    elif mode == 'list':
        list()
    elif mode == 'play':
        play()
    elif mode == 'search':
        search()
