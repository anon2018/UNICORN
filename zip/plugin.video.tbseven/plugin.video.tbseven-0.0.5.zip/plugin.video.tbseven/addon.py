# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
from CommonFunctions import parseDOM

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.tbseven')
autologin = ''
session = ''

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, image, folder, payload):
    list_item = xbmcgui.ListItem(label=name)

    if folder:
        list_item.setProperty("IsPlayable", 'false')
    else:
        list_item.setProperty("IsPlayable", 'true')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=folder
    )


def login():
    global autologin
    global session

    username = addon.getSetting('username')
    password = addon.getSetting('password')
    url = 'https://tb7.pl/login'

    if username and password:
        response = requests.post(
            url,
            verify=False,
            allow_redirects=False,
            data={'login': username, 'password': password}
        )
        autologin = response.cookies['autologin']
        session = response.cookies['session']
    else:
        xbmcgui.Dialog().ok('tb7 Player', 'Podaj dane logowania w ustawieniach wtyczki.')


def home():
    login()

    url = 'https://tb7.pl/mojekonto/pliki'
    response = requests.get(
        url,
        verify=False,
        cookies={'autologin': autologin, 'session': session, 'cookie_accept': 'true'}
    )

    table = parseDOM(response.content, 'table', attrs={'class': 'list'})[0]
    tbody = parseDOM(table, 'tbody')
    rows = parseDOM(tbody, 'tr')

    for index, row in enumerate(rows):
        cells = parseDOM(row, 'td')
        if len(cells) > 4:
            expire = cells[4].encode('utf-8')
            name = parseDOM(cells[1], 'a')[0].replace('.../', '').encode('utf-8')
            link = parseDOM(cells[1], 'a', ret='href')[0]
        else:
            expire = '---'
            name = '---'

        print(link)
        name = name + '    -    Wygasa: ' + expire

        if cells[2] != '-':
            add_item(name, '', False, {'mode': 'play', 'link': link})

    xbmcplugin.endOfDirectory(addon_handle)


def play():
    link = params.get('link', None)
    play_item = xbmcgui.ListItem(path=link)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'play':
        play()
