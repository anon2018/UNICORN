# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
from CommonFunctions import parseDOM
from ptw.libraries import client

reload(sys)
sys.setdefaultencoding('utf8')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.tbseven')
autologin = ''
session = requests.session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, image, folder, payload):
    list_item = xbmcgui.ListItem(label=name)

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=folder
    )


def login():
    global autologin
    username = addon.getSetting('username')
    password = addon.getSetting('password')
    url = 'https://tb7.pl/login'

    if username and password:
        session.post(
            url,
            verify=False,
            allow_redirects=False,
            data={'login': username, 'password': password}
        )
    else:
        xbmcgui.Dialog().ok('tb7 Player', 'Podaj dane logowania w ustawieniach wtyczki.')


def home():
    login()
    session.get("https://tb7.pl/", verify=False)
    url = 'https://tb7.pl/mojekonto/pliki'
    response = session.get(url, verify=False)

    table = parseDOM(response.content, 'table', attrs={'class': 'list'})[0]
    tbody = parseDOM(table, 'tbody')
    rows = parseDOM(tbody, 'tr')

    for index, row in enumerate(rows):
        cells = parseDOM(row, 'td')
        if len(cells) > 4:
            expire = cells[4].encode('utf-8')
            name = parseDOM(cells[1], 'a')[0].replace('.../', '').encode('utf-8')
            link = parseDOM(cells[1], 'a', ret='href')[0]
        else:
            expire = '---'
            name = '---'

        print(link)
        name = name + '  -  Wygasa: ' + expire

        if cells[2] != '-':
            import urllib
            add_item(urllib.unquote(name), '', False, {'mode': 'play', 'link': link})

    xbmcplugin.endOfDirectory(addon_handle)


def play():
    headers = {
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.53 Safari/537.36',
        'DNT': '1',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
    }

    import xbmc
    link = params.get('link', None)
    link = session.get(link, headers=headers, verify=False, allow_redirects=False)
    if link.status_code == 200:
        if 'dla podanego linka Premium' in link.content:
            xbmcgui.Dialog().ok('Error', 'Osiągnięto limit pobrań dla podanego linka Premium')
            return
    link = link.headers['Location']
    xbmc.Player().play(link + "|User-Agent=vlc/3.0.0-git libvlc/3.0.0-git&verifypeer=false")

def menu():
    add_item("Wyszukaj", '', True, {'mode': 'search'})
    add_item("Biblioteka", '', True, {'mode': 'home'})

if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        menu()
    elif mode == 'home':
        home()
    elif mode == 'search':
        import xbmc
        login()
        keyb = xbmc.Keyboard('', "Wyszukiwarka")
        keyb.doModal()
        if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
            search = keyb.getText()
            data = {
                'type': '1',
                'search': search
            }

            r = session.post('https://tb7.pl/mojekonto/szukaj', data=data).content

            rows = client.parseDOM(r, 'tr')

            if not r:
                addon.addDir("Zbyt dużo lub brak wyników wyszukiwania :(", '')
                addon.addDir("Spróbuj doprecyzować zapytanie!", '')

            for row in rows:
                try:
                    nazwa = client.parseDOM(row, 'label')[0]
                    link = client.parseDOM(row, 'input', ret='value')[0]
                    size = client.parseDOM(row, 'td')[3]
                    add_item(nazwa + ' ' + size, '', True, {'mode': 'dodaj', 'input': link})
                except:
                    continue
            add_item('Nastepna strona', '', True, {'mode': 'nastepna', 'strona': '1', 'search': search})
        else:
            menu()
    elif mode == 'nastepna':
        search = params.get('search', None)
        strona = params.get('strona', None)
        login()
        data = {
            'type': '1',
            'search': search
        }

        r = session.post('https://tb7.pl/mojekonto/szukaj/' + strona, data=data).content
        strona = str(int(strona)+1)

        rows = client.parseDOM(r, 'tr')

        if not r:
            addon.addDir("Zbyt dużo lub brak wyników wyszukiwania :(", '')
            addon.addDir("Spróbuj doprecyzować zapytanie!", '')

        for row in rows:
            try:
                nazwa = client.parseDOM(row, 'label')[0]
                link = client.parseDOM(row, 'input', ret='value')[0]
                size = client.parseDOM(row, 'td')[3]
                add_item(nazwa + ' ' + size, '', True, {'mode': 'dodaj', 'input': link})
            except:
                continue
        add_item('Nastepna strona', '', True, {'mode': 'nastepna', 'strona': strona, 'search': search})
    elif mode == 'dodaj':
        login()
        input = params.get('input', None)
        data = {
            'step': '1',
            'content': input
        }
        session.post('https://tb7.pl/mojekonto/sciagaj', data=data)

        data = {
            '0': 'on',
            'step': '2'
        }

        content = session.post('https://tb7.pl/mojekonto/sciagaj', data=data).content
        home()

    elif mode == 'play':
        play()

xbmcplugin.endOfDirectory(addon_handle)