# -*- coding: UTF-8 -*-
import re
import xbmc
import xbmcgui
import xbmcplugin

import requests
import resolveurl
import sys

reload(sys)
sys.setdefaultencoding('UTF8')

try:
    import HTMLParser
    from HTMLParser import HTMLParser
except:
    from html.parser import HTMLParser

import addon_utils as addon
import client, cache, cloudflare, control


_pluginName = sys.argv[0].replace('plugin://', '')
_basePath = "special://home/addons/" + _pluginName + "resources/media/"
_resourcesPath = xbmc.translatePath(_basePath)
_default_background = _resourcesPath + "fanart.jpg"
_base_link = "http://exsite24.pl/"
debrid_resolvers = []

_headers = {
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'DNT': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.80 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
}

_data = {
        'login_name': control.setting('user'),
        'login_password': control.setting('pass'),
        'login': 'submit',
        'login_s': 'Zaloguj'
    }

# =########################################################################################################=#
#                                                   MENU                                                   #
# =########################################################################################################=#

def status():
    return debrid_resolvers != []

def resolver_debrid(url, debrid):
    try:
        debrid_resolver = [resolver for resolver in debrid_resolvers if resolver.name == debrid][0]

        debrid_resolver.login()
        _host, _media_id = debrid_resolver.get_host_and_id(url)
        stream_url = debrid_resolver.get_media_url(_host, _media_id)

        return stream_url
    except Exception as e:
        print(str(e))
        return None

def cookiesToDict(cookie):
    from Cookie import SimpleCookie

    rawdata = cookie
    cookie = SimpleCookie()
    cookie.load(rawdata)
    cookies = {}
    for key, morsel in cookie.items():
        cookies[key] = morsel.value
    return cookies

def cookiesToString(cookies):
    return "; " + "; ".join([str(x) + "=" + str(y) for x, y in cookies.items()])

def cloudflareAuth(url):
    s = requests.session()
    cf = cloudflare.Cloudflare(url, headers=_headers)
    if cf.is_cloudflare:
        authUrl = cf.get_url()
        makeAuth = s.get(authUrl, headers=_headers)
    return s.cookies

def loadCookieFromCache(cache_name):
    cookie = cache.cache_get(cache_name)
    if type(cookie) is dict:
        cookie = str(cookie['value'])
    return cookiesToDict(cookie)

def CATEGORIES():
    cookies = cloudflareAuth(_base_link)
    cookies_string = cookiesToString(cookies)

    logowanie = requests.post(_base_link, data=_data, headers=_headers, cookies=cookies)
    cookie = re.findall("; (.*)", cookies_string)[0]
    cookiesPoZalogowaniu = cookie + "; " + "; ".join([str(x) + "=" + str(y) for x, y in logowanie.cookies.items()])
    cache.cache_insert('exsite_cookie', str(cookiesPoZalogowaniu))

    addon.addDir("Szukaj materiału", '', mode=1)
    addon.addDir("Filmy", '', mode=20)
    addon.addDir("Seriale", '', mode=21)
    addon.addDir("Bajki", url='http://exsite24.pl/bajki_kreskowki/', mode=10)
    addon.addDir("Filmy Online", url="http://exsite24.pl/filmy-online", mode=10)
    addon.addDir("Anime", url="http://exsite24.pl/anime/", mode=10)
    addon.addDir("Sport", url="http://exsite24.pl/sport/", mode=10)
    addon.addDir("[XXX] Filmy, Clipy", url="http://www.exsite24.pl/xxx/xxx-filmy/", mode=10)
    addon.addDir("[XXX] Filmy pełnometrażowe", url="http://www.exsite24.pl/xxx/xxx-pelnometrazowe/", mode=10)
    addon.addDir("[XXX] Hentai", url="http://www.exsite24.pl/xxx/xxx-hentai/", mode=10)


############################################################################################################
# =########################################################################################################=#
#                                                 FUNCTIONS                                                #
# =########################################################################################################=#

def Wyszukiwanie():
    keyb = xbmc.Keyboard('', "Wyszukiwarka materialu")
    keyb.doModal()
    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()
        url = "http://exsite24.pl/index.php?do=search&subaction=search&search_start=0&full_search=0&result_from=1&story=" + search.replace(" ","+")
        cookies = loadCookieFromCache('exsite_cookie')
        r = requests.get(url, headers=_headers, cookies=cookies).content
        result = client.parseDOM(r, 'div', attrs={'class': 'movie boxed'})
        for item in result:
            try:
                link = client.parseDOM(item, 'a', ret='href')[0]
                tytul = client.parseDOM(item, 'a')[0]
                poster = client.parseDOM(item, 'img', ret='src')[0]
                addon.addDir(str(tytul), link, mode=3, poster=poster, thumb=poster)
            except:
                continue
        try:
            next = client.parseDOM(r, 'li', attrs={'class': 'next'})
            next = client.parseDOM(next, 'a', ret='href')[0]
            addon.addDir(str('Następna strona >'), next, mode=10)
        except:
            pass
    else:
        CATEGORIES()


def Listuj():
    cookies = loadCookieFromCache('exsite_cookie')
    url = params['url']
    r = requests.get(url, headers=_headers, cookies=cookies).content
    result = client.parseDOM(r, 'div', attrs={'class': 'movie boxed'})
    for item in result:
        try:
            link = client.parseDOM(item, 'a', ret='href')[0]
            tytul = client.parseDOM(item, 'a')[0]
            poster = client.parseDOM(item, 'img', ret='src')[0]
            addon.addDir(str(tytul), link, mode=3, poster=poster, thumb=poster)
        except:
            continue
    try:
        next = client.parseDOM(r, 'li', attrs={'class': 'next'})
        next = client.parseDOM(next, 'a', ret='href')[0]
        addon.addDir(str('Następna strona >'), next, mode=10)
    except:
        pass

def ListujLinki():
    url = params['url']
    cookies = loadCookieFromCache('exsite_cookie')
    r = requests.get(url, headers=_headers, cookies=cookies).content
    result = client.parseDOM(r, 'div', attrs={'class': 'movie boxed'})[0]
    h = HTMLParser()
    result = h.unescape(result)
    result = client.parseDOM(result, 'pre', attrs={'class': 'scriptcode'})
    for item in result:
        if 'part' in item or not 'http' in item:
            continue
        items = item.split()
        for link in items:
            addon.addLink(link, link, mode=6)

def OdpalanieLinku():
    try:
        global debrid_resolvers
        debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if
                            resolver.isUniversal()]

        if len(debrid_resolvers) == 0:
            # Support Rapidgator accounts! Unfortunately, `sources.py` assumes that rapidgator.net is only ever
            # accessed via a debrid service, so we add rapidgator as a debrid resolver and everything just works.
            # As a bonus(?), rapidgator links will be highlighted just like actual debrid links
            debrid_resolvers = [resolver() for resolver in
                                resolveurl.relevant_resolvers(order_matters=True, include_universal=False) if
                                'rapidgator.net' in resolver.domains]
    except:
        debrid_resolvers = []
    url = params['url']
    link = resolver_debrid(url, 'Real-Debrid')
    if not link:
        try:
            link = resolveurl.resolve(url)
        except Exception as e:
            xbmcgui.Dialog().ok('Error', 'Błąd odpalania linku! %s' % e)
            sys.exit()
    try:
        pDialog = xbmcgui.DialogProgress()
        xbmc.Player().play(link)
    except Exception as e:
        pDialog.close()
        xbmcgui.Dialog().ok('Error', 'Błąd odpalania linku! %s' % e)


############################################################################################################
# =########################################################################################################=#
#                                               GET PARAMS                                                 #
# =########################################################################################################=#

params = addon.get_params()
url = params.get('url')
name = params.get('name')
try:
    mode = int(params.get('mode'))
except:
    mode = None
iconimage = params.get('iconimage')

###############################################################################################################
# =###########################################################################################################=#
#                                                   MODES                                                     #
# =###########################################################################################################=#

if mode == None:
    CATEGORIES()

elif mode == 1:
    Wyszukiwanie()

elif mode == 3:
    ListujLinki()

elif mode == 6:
    OdpalanieLinku()

elif mode == 10:
    Listuj()

elif mode == 20:
    addon.addDir("Wszystkie Filmy", url='http://exsite24.pl/filmy_video_movies', mode=10)
    addon.addDir("Filmy 4K UHD", url='http://exsite24.pl/filmy_video_movies/filmy_4k_uhd/', mode=10)
    addon.addDir("Blu-ray Disc, Remux", url='http://exsite24.pl/filmy_video_movies/filmy_blu-ray_disc_remux/', mode=10)
    addon.addDir("DVDRip, BRRip, BDRip, NF", url='http://exsite24.pl/filmy_video_movies/filmy-dvdrip-brrip-nf/', mode=10)
    addon.addDir("HD, DVD, WEB-DL", url='http://exsite24.pl/filmy_video_movies/filmy-hd-dvd5-dvd9/', mode=10)
    addon.addDir("3D HOU SBS", url='http://exsite24.pl/filmy_video_movies/filmy-3d-sbs/', mode=10)
    addon.addDir("WEBRip, DVDScr", url='http://exsite24.pl/filmy_video_movies/filmy-r5-dvdscr/', mode=10)
    addon.addDir("SCR, TS, TC, WP, CAM", url='http://exsite24.pl/filmy_video_movies/filmy-scr-ts-tc-wp-cam/', mode=10)
    addon.addDir("Filmy Dokumentalne", url='http://exsite24.pl/filmy_video_movies/filmy-dokumentalne/', mode=10)
    addon.addDir("Filmy Bollywood", url='http://exsite24.pl/filmy_video_movies/filmy-bollywood/', mode=10)

elif mode == 21:
    addon.addDir("Wszystkie Seriale", url='http://exsite24.pl/seriale/', mode=10)
    addon.addDir("Zagraniczne", url='http://exsite24.pl/seriale/seriale-zagraniczne/', mode=10)
    addon.addDir("Lektor", url='http://exsite24.pl/seriale/seriale-lektor/', mode=10)
    addon.addDir("Polskie", url='http://exsite24.pl/seriale/seriale-polskie/', mode=10)

###################################################################################

xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
