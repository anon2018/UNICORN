# -*- coding: UTF-8 -*-
import sys

import xbmcplugin
from future.moves.html.parser import HTMLParser
from ptw.libraries import addon_utils as addon
from ptw.libraries import client

homepage = "https://stand-upy.pl/"

# =########################################################################################################=#
#                                                   MENU                                                   #
# =########################################################################################################=#


def CATEGORIES():
    addon.addDir("Ostatnio dodane", homepage, mode=10)
    addon.addDir("Najczesciej ogladane", homepage, mode=20)
    addon.addDir("Komicy polscy", homepage, mode=30)
    addon.addDir("Komicy zagraniczni", homepage, mode=40)


############################################################################################################
# =########################################################################################################=#
#                                                 FUNCTIONS                                                #
# =########################################################################################################=#

def ostatnioDodane():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'col-sm-6 col-xs-6 item responsive-height post'})[:-8]

    for item in result:
        try:
            image = str(client.parseDOM(item, 'img', ret='src')[0])
            item = client.parseDOM(item, 'h3')
            nazwa = str(client.parseDOM(item, 'a')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            addon.addLink(nazwa, link, mode=5, thumb=image, poster=image)
        except:
            continue

def najczesciejOgladane():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'col-sm-6 col-xs-6 item responsive-height post'})[-8:-4]

    for item in result:
        try:
            image = str(client.parseDOM(item, 'img', ret='src')[0])
            item = client.parseDOM(item, 'h3')
            nazwa = str(client.parseDOM(item, 'a')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            addon.addLink(nazwa, link, mode=5, thumb=image, poster=image)
        except:
            continue

def polscyKomicy():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'ul', attrs={'class': 'dropdown-menu'})[0]
    result = client.parseDOM(result, 'li')

    for item in result:
        try:
            nazwa = str(client.parseDOM(item, 'a')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            addon.addDir(nazwa, link, mode=6)
        except:
            continue


def zagraniczniKomicy():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'ul', attrs={'class': 'dropdown-menu'})[1]
    result = client.parseDOM(result, 'li')

    for item in result:
        try:
            nazwa = str(client.parseDOM(item, 'a')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            addon.addDir(nazwa, link, mode=6)
        except:
            continue


def listowanieVideo():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'col-sm-4 col-xs-6 item responsive-height'})

    for item in result:
        try:
            image = str(client.parseDOM(item, 'img', ret='src')[0])
            item = client.parseDOM(item, 'h3')
            nazwa = str(client.parseDOM(item, 'a')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            addon.addLink(nazwa, link, mode=5, thumb=image, poster=image)
        except:
            continue

def odpalanie():
    url = params['url']
    r = client.request(url)
    link = str(client.parseDOM(r, 'iframe', ret='src')[0])
    addon.PlayMedia(link)

############################################################################################################
# =########################################################################################################=#
#                                               GET PARAMS                                                 #
# =########################################################################################################=#

params = addon.get_params()
url = params.get('url')
name = params.get('name')
try:
    mode = int(params.get('mode'))
except:
    mode = None
iconimage = params.get('iconimage')

###############################################################################################################
# =###########################################################################################################=#
#                                                   MODES                                                     #
# =###########################################################################################################=#

if mode == None:
    CATEGORIES()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 10:
    ostatnioDodane()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 20:
    najczesciejOgladane()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 30:
    polscyKomicy()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 40:
    zagraniczniKomicy()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 6:
    listowanieVideo()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 5:
    odpalanie()
###################################################################################
