# -*- coding: UTF-8 -*-
import sys

import requests
import xbmc
import xbmcplugin
from future.moves.html.parser import HTMLParser
from ptw.libraries import addon_utils as addon
from ptw.libraries import client


# =########################################################################################################=#
#                                                   MENU                                                   #
# =########################################################################################################=#


def CATEGORIES():
    addon.addDir("Wyszukiwarka", '', mode=1)

    addon.addDir("Wszystkie Alfabetycznie",
                 'https://animeon.pl/anime-online?sortBy=title&sortType=asc&type=all&status=all', mode=10)
    addon.addDir("Wszystkie Ilosc ocen",
                 'https://animeon.pl/anime-online?sortBy=rated_users&sortType=desc&type=all&status=all', mode=10)


############################################################################################################
# =########################################################################################################=#
#                                                 FUNCTIONS                                                #
# =########################################################################################################=#


def Wyszukiwanie():
    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()
    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()
        link = "https://animeon.pl/anime-online?search=%s&sortBy=rated_users&sortType=desc&type=all&status=all" % search.replace(
            " ", "+").lower()
        r = client.request(link)
        h = HTMLParser()
        r = h.unescape(r)

        result = client.parseDOM(r, 'div', attrs={'class': 'movie-item-style-2'})
        for item in result:
            try:
                poster = str(client.parseDOM(item, 'img', ret='src')[0])
                item = client.parseDOM(item, 'div', attrs={'class': 'mv-item-infor'})
                nazwa = str(client.parseDOM(item, 'i', ret='title')[0])
                opis = str(client.parseDOM(item, 'i', ret='data-content')[0])
                link = str(client.parseDOM(item, 'a', ret='href')[0])
                ocena = str(client.parseDOM(item, 'p', attrs={'class': 'rate'}))
                ocena = str(float(client.parseDOM(ocena, 'span')[0]) * 2)
                gatunek = str(client.parseDOM(item, 'span', attrs={'class': 'time'}))
                gatunek = client.parseDOM(gatunek, 'a')
                addon.addDir(nazwa, link, mode=6, thumb=poster, poster=poster, plot=opis, rating=ocena, genre=gatunek)
            except:
                continue
        try:
            nextPage = client.parseDOM(r, 'div', attrs={'class': "pagination2 text-center"})
            nextPage = str(client.parseDOM(nextPage, 'a', ret='href')[-1])
            addon.addDir("Nastepna strona ->", nextPage, mode=10)
        except:
            pass
    else:
        CATEGORIES()


def ListowanieAnime():
    url = params['url']

    r = client.request(url)
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'movie-item-style-2'})

    for item in result:
        try:
            poster = str(client.parseDOM(item, 'img', ret='src')[0])
            item = client.parseDOM(item, 'div', attrs={'class': 'mv-item-infor'})
            nazwa = str(client.parseDOM(item, 'i', ret='title')[0])
            opis = str(client.parseDOM(item, 'i', ret='data-content')[0])
            link = str(client.parseDOM(item, 'a', ret='href')[0])
            ocena = str(client.parseDOM(item, 'p', attrs={'class': 'rate'}))
            ocena = str(float(client.parseDOM(ocena, 'span')[0]) * 2)
            gatunek = str(client.parseDOM(item, 'span', attrs={'class': 'time'}))
            gatunek = client.parseDOM(gatunek, 'a')
            addon.addDir(nazwa, link, mode=6, thumb=poster, poster=poster, plot=opis, rating=ocena, genre=gatunek)
        except:
            continue
    try:
        nextPage = client.parseDOM(r, 'div', attrs={'class': "pagination2 text-center"})
        nextPage = str(client.parseDOM(nextPage, 'a', ret='href')[-1])
        addon.addDir("Nastepna strona ->", nextPage, mode=10)
    except:
        pass


def ListowaniOdcinkow():
    url = params['url']
    r = client.request(url + "/odcinki")
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'vd-infor'})

    for item in result:
        link = client.parseDOM(item, 'a', ret='href')[0]
        nazwa = client.parseDOM(item, 'a')[0]
        if nazwa and link:
            addon.addLink(str(nazwa), str(link), mode=5)


def WysiwetlanieLinkow():
    url = params['url']
    s = requests.session()
    r = s.get(url).content
    h = HTMLParser()
    r = h.unescape(r)

    result = client.parseDOM(r, 'div', attrs={'class': 'video-nav thumb-ft'})[0]

    import re, json
    result = re.findall(r"""data-id=\"(.*?)\"""", result)
    token = re.findall(r"""token = \"(.*?)\"""", r)[0]

    items = []
    for item in result:
        try:
            link = "https://animeon.pl/players/get-player-url/%s" % item
            item = json.loads(s.post(link, data={'_token': token}).content)
            items.append({'href': item[u'link'],
                          'name': item[u'subs_lang'].upper() + ' ' + item[u'service'] + ' ' + item[u'quality']})
        except:
            continue
    addon.SourceSelect(items)


############################################################################################################
# =########################################################################################################=#
#                                               GET PARAMS                                                 #
# =########################################################################################################=#

params = addon.get_params()
url = params.get('url')
name = params.get('name')
try:
    mode = int(params.get('mode'))
except:
    mode = None
iconimage = params.get('iconimage')

###############################################################################################################
# =###########################################################################################################=#
#                                                   MODES                                                     #
# =###########################################################################################################=#

if mode == None:
    CATEGORIES()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 1:
    Wyszukiwanie()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 10:
    ListowanieAnime()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 6:
    ListowaniOdcinkow()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 5:
    WysiwetlanieLinkow()
###################################################################################
