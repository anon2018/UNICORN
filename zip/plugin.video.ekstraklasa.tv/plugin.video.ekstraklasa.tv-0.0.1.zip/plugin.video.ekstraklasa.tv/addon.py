# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import inputstreamhelper

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.ekstraklasa.tv')
resources = xbmc.translatePath(addon.getAddonInfo('path') + '/resources/')

limit = 50

main_url = 'http://mobileapps.mobile.onetapi.pl'
list_url = 'http://onetnewsapi.mobile.onetapi.pl'
video_url = 'http://qi.ckm.onetapi.pl/'

headers = {
    'Content-Type': 'application/json-rpc',
    'X-Onet-App': 'ekstraklasa.ios.mobile-apps.onetapi.pl',
    'User-Agent': 'Ekstraklasa.TV/1.7 (iPhone; iOS 12.0; Scale/2.00)',
    'Accept-Language': 'pl-PL;q=1'
}


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, image, is_folder, is_playble, payload, plot=''):
    list_item = xbmcgui.ListItem(label=name)

    if is_playble:
        list_item.setProperty("IsPlayable", 'true')
    else:
        list_item.setProperty("IsPlayable", 'false')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name, 'plot': plot})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=is_folder
    )


def play():
    id = params.get('id', None)

    data = {
        'jsonrpc': '2.0',
        'id': 'idontcare',
        'method': 'getDetail',
        'params': {'id': 'PULS_CMS-ShortVideo-' + id,
                  'playlistAllow': 'true'
                  }
    }

    response = requests.post(
        list_url,
        json=data,
        verify=False,
        headers=headers
    ).json()

    publication_id = response.get('result', None).get('manifest', None).get('ref_1', None).get('content', None).get('blocks', None)[0].get('data', None).get('publicationId', None).get('mvp', None)

    response = requests.post(
        video_url,
        data='{"jsonrpc": "2.0","id": "-2119709984","method": "get_asset_detail","params": {"ID_Publikacji":"' + publication_id + '","device": "mobile","Service": "vod.onet.pl"}}',
        verify=False,
        headers={
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Onet-App': 'APP_EKSTRAKLASA_TV_IOS',
            'User-Agent': 'Ekstraklasa.TV/2 CFNetwork/955.1.2 Darwin/18.0.0',
            'Accept-Language': 'pl-PL;q=1'
        }
    ).json()

    def play_standard():
        manifest = response.get('result', None).get('0', None).get('formats', None).get('wideo', None).get('mp4', None)[0].get('url', None)
        play_item = xbmcgui.ListItem(path=manifest)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

    if addon.getSetting('inputstream') == 'true':
        is_helper = inputstreamhelper.Helper('mpd')
        if is_helper.check_inputstream():
            manifest = response.get('result', None).get('0', None).get('formats', None).get('wideo', None).get('mpd', None)[0].get('url', None)
            play_item = xbmcgui.ListItem(path=manifest)
            play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            play_standard()
    else:
        play_standard()


def list():
    id = params.get('id', 'EkstraklasaApp-Onet-List-Sg')
    page = int(params.get('page', '0'))

    data = {'jsonrpc': '2.0',
            'id': 'idontcare',
            'method': 'getListById',
            'params':{'cnt_cdp_id': id,
                      'to': limit * (page + 1),
                      'from': limit * page
                      }
            }

    response = requests.post(
        list_url,
        json=data,
        verify=False,
        headers=headers
    ).json()

    items = response.get('result', {}).get('elements', [])
    for item in items:
        title = item.get('title', '')
        lead = item.get('lead', '')
        image = item.get('imageOriginal', {}).get('url', '')
        uuid = item.get('uuid', None)
        add_item(title, image, False, True, {'mode': 'play', 'id': uuid}, lead)

    page += 1

    if len(items) == limit:
        add_item('NASTĘPNA STRONA >>', resources + 'transparent.png', True, False, {'mode': 'list', 'page': str(page)})

    xbmcplugin.endOfDirectory(addon_handle)


def home():
    data = {'jsonrpc': '2.0',
            'id': 'idontcare',
            'method': 'getSportDisciplinesNew',
            'params': {'appname': 'ekstraklasaAndroid'}
            }

    response = requests.post(
        main_url,
        json=data,
        verify=False,
        headers=headers
    ).json()

    add_item('Wszystkie', resources + 'transparent.png', True, False, {'mode': 'list', 'id': 'EkstraklasaApp-Ekstraklasa-List-Sg'})
    items = response.get('result', None).get('disciplines', None)[0].get('children', None)
    for item in items:
        title = item.get('label', '')
        icon = item.get('icon', '')
        id = item.get('news', None).get('ekstraklasaListId', None)
        add_item(title, icon, True, False, {'mode': 'list', 'id': id})

    xbmcplugin.endOfDirectory(addon_handle)


if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'list':
        list()
    elif mode == 'play':
        play()
