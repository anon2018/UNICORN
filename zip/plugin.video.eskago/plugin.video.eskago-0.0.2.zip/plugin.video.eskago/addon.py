import sys
from urlparse import parse_qsl
import urllib
import pickle
import requests
import xbmcaddon
import xbmcgui
import xbmcplugin
from xml.etree import ElementTree
import HTMLParser


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_folder(name, param):
        list_item = xbmcgui.ListItem(name.capitalize())
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url(param),
            listitem=list_item,
            isFolder=True
        )


def add_item(movie_id, name, content_rating, cover, image):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setProperty("IsPlayable", 'true')
    list_item.setInfo(type='video', infoLabels={'title': name, "mpaa": content_rating, 'sorttitle': name})
    if cover == '':
        cover = image
    list_item.setArt({'thumb': cover, 'poster': cover, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': 'play', 'id': movie_id}),
        listitem=list_item,
        isFolder=False
    )


def add_serie(name, url, image, description):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setProperty("IsPlayable", 'false')
    list_item.setInfo(type='video', infoLabels={'plot': description, 'title': name, 'sorttitle': name})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': 'season', 'url': url}),
        listitem=list_item,
        isFolder=True
    )


def add_season(name, url, image, description):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setProperty("IsPlayable", 'false')
    list_item.setInfo(type='video', infoLabels={'plot': description, 'title': name, 'sorttitle': name})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': 'episodes', 'url': url}),
        listitem=list_item,
        isFolder=True
    )


def add_program(name, items):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setProperty("IsPlayable", 'false')
    list_item.setInfo(type='video', infoLabels={ 'title': name, 'sorttitle': name})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': 'program', 'items': pickle.dumps(items)}),
        listitem=list_item,
        isFolder=True
    )


def home():
    add_folder('Filmy', {'mode': 'groups'})
    add_folder('Seriale', {'mode': 'series'})
    add_folder('Programy', {'mode': 'programs'})
    xbmcplugin.endOfDirectory(addon_handle)


def movie_groups():
    categories = requests.get(
        'http://www.eskago.pl/indexajax.php?action=MobileApi&start=vodCategories&type=movies&filter=categories&api=1.5',
        verify=False
    )
    genres = requests.get(
        'http://www.eskago.pl/indexajax.php?action=MobileApi&start=vodCategories&type=movies&filter=genres&api=1.5',
        verify=False
    )

    categories_tree = ElementTree.fromstring(categories.content)
    genres_tree = ElementTree.fromstring(genres.content)

    def parse(elem):
        name = elem.find('name').text.encode('utf-8')
        url = elem.find('url').text.encode('utf-8')
        add_folder(name, {'mode': 'movies', 'url': url})

    for group in categories_tree:
        parse(group)

    for group in genres_tree:
        parse(group)

    xbmcplugin.endOfDirectory(addon_handle)


def movies():
    xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)

    url = params.get('url', None)
    url = url.replace('[OFFSET]', '0')
    url = url.replace('[LIMIT]', '99')
    content = requests.get(
        url,
        verify=False
    ).content
    movies_tree = ElementTree.fromstring(content)
    items = movies_tree.find('items')
    if items is not None:
        for movie in items:
            movie_id = movie.find('id').text.encode('utf-8')
            name = movie.find('name').text.encode('utf-8')
            content_rating = movie.find('contentRating').text.encode('utf-8')
            cover = movie.find('cover').text.encode('utf-8').replace('[WIDTH]', '340.000000')
            image = movie.find('image').text.encode('utf-8').replace('[WIDTH]', '960.000000')
            add_item(movie_id, name, content_rating, cover, image)
    xbmcplugin.endOfDirectory(addon_handle)


def play():
    movie_id = params.get('id', None)
    url = 'http://www.eskago.pl/indexajax.php?action=MobileApi&start=moviev2&api=1.5&id='+movie_id
    content = requests.get(
        url,
        verify=False
    ).content
    movie_tree = ElementTree.fromstring(content)
    stream_url = movie_tree.find('streams').find('Stream').find('url').text.encode('utf-8')
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


def series():
    xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    content = requests.get(
        'http://www.eskago.pl/indexajax.php?action=MobileApi&start=getSeries&api=1.5',
        verify=False
    ).content

    series_tree = ElementTree.fromstring(content)
    for serie in series_tree:
        url = serie.find('url').text.encode('utf-8')
        name = serie.find('series').find('Series').find('name').text.encode('utf-8')
        image = serie.find('series').find('Series').find('image').text.encode('utf-8').replace('[WIDTH]', '480.000000')
        description = serie.find('series').find('Series').find('description')
        if description is not None:
            description = HTMLParser.HTMLParser().unescape(description.text)
            description = description.encode('utf-8')
            print(description)
        add_serie(name, url, image, description)
    xbmcplugin.endOfDirectory(addon_handle)


def season():
    url = params.get('url', None)
    content = requests.get(
        url,
        verify=False
    ).content

    series_tree = ElementTree.fromstring(content)
    for season in series_tree.find('series').find('Series').find('items'):
        url = season.find('url').text.encode('utf-8')
        name = 'Sezon ' + season.find('name').text.encode('utf-8')
        image = season.find('image').text.encode('utf-8').replace('[WIDTH]', '480.000000')
        description = season.find('description')
        if description is not None:
            description = HTMLParser.HTMLParser().unescape(description.text)
            description = description.encode('utf-8')
        add_season(name, url, image, description)
    xbmcplugin.endOfDirectory(addon_handle)


def episodes():
    url = params.get('url', None)
    content = requests.get(
        url,
        verify=False
    ).content

    episodes_tree = ElementTree.fromstring(content)
    items = episodes_tree.find('items')
    if items is not None:
        for movie in items:
            movie_id = movie.find('id').text.encode('utf-8')
            name = movie.find('name').text.encode('utf-8')
            content_rating = movie.find('contentRating').text.encode('utf-8')
            image = movie.find('image').text.encode('utf-8').replace('[WIDTH]', '960.000000')
            add_item(movie_id, name, content_rating, '', image)
    xbmcplugin.endOfDirectory(addon_handle)


def programs():
    xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    content = requests.get(
        'http://www.eskago.pl/indexajax.php?action=MobileApi&start=getPackage&id=programsmobile&api=1.5',
        verify=False
    ).content

    programs_tree = ElementTree.fromstring(content)
    for program in programs_tree:
        items = []
        for item in program.find('items'):
            items.append({
                'id': item.find('id').text.encode('utf-8'),
                'name': item.find('name').text.encode('utf-8'),
                'cover': item.find('cover').text.encode('utf-8').replace('[WIDTH]', '340.000000'),
                'image': item.find('image').text.encode('utf-8').replace('[WIDTH]', '960.000000'),
                'contentRating': item.find('contentRating').text.encode('utf-8')
            })
        name = program.find('series').find('Series').find('name').text.encode('utf-8')
        add_program(name, items)
    xbmcplugin.endOfDirectory(addon_handle)


def program():
    items = pickle.loads(params.get('items', None))
    for item in items:
        add_item(item.get('id', None), item.get('name', None), item.get('contentRating', None), item.get('cover', None), item.get('image', None))
    xbmcplugin.endOfDirectory(addon_handle)


if __name__ == '__main__':
    mode = params.get('mode', None)

    if not mode:
        home()
    elif mode == 'groups':
        movie_groups()
    elif mode == 'movies':
        movies()
    elif mode == 'play':
        play()
    elif mode == 'series':
        series()
    elif mode == 'season':
        season()
    elif mode == 'episodes':
        episodes()
    elif mode == 'programs':
        programs()
    elif mode == 'program':
        program()
