# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2017 - Victor
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.mboxtime'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[       	
		("", "", ''),
		("[COLOR aqua]>>NEWS<<[/COLOR]", "", ''),
		("Serwis", "channel/UCLBRvAv_yg8IPuG2aj_TvUQ", 'https://yt3.ggpht.com/-DoBGP4IG7cU/AAAAAAAAAAI/AAAAAAAAAAA/MGprRa-m6W4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("Rozmowy Polityczne", "http://cherrytv.webd.pl/goldvod.m3u", 'https://yt3.ggpht.com/-f9VLZZXdA20/AAAAAAAAAAI/AAAAAAAAAAA/g7cmXjS_qJE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("W Polsce TV", "channel/UCPiu4CZlknkTworskK79CPg", 'https://yt3.ggpht.com/-qEQ6M8nbQ0I/AAAAAAAAAAI/AAAAAAAAAAA/-DIo2oKL9w0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("TV Republika", "channel/UCc282c_TN8xIba_Z6GaDnQw", 'https://yt3.ggpht.com/-Dxy8cCYpUic/AAAAAAAAAAI/AAAAAAAAAAA/ZTJb5b9GmQE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("W Realu 24", "channel/UCiwsDgj8mJnsGOr6oN-2OVQ", 'https://yt3.ggpht.com/-a_SDTnbrCtM/AAAAAAAAAAI/AAAAAAAAAAA/8lP6eiFWykQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
		("Pyta PL", "channel/UC7xj2xj0EtGt8EZ3ERJf-IQ", 'https://yt3.ggpht.com/-d59Jy_rIipA/AAAAAAAAAAI/AAAAAAAAAAA/ibrBr-ZyG0A/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("RMF 24", "channel/UCkC9YgH_FlqOhOIoTDFt4CA", 'https://yt3.ggpht.com/-D76s2vhMtX0/AAAAAAAAAAI/AAAAAAAAAAA/DBRSSqCGusc/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>FILMY<<[/COLOR]", "", ''),
		("Kino Swiat VOD", "channel/UCDqUHYuQcF191eT3_eydXGw", 'https://yt3.ggpht.com/-joiHMwRf2wg/AAAAAAAAAAI/AAAAAAAAAAA/O43o0xr4J6w/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("Super Film VOD", "channel/UC7A5iwFhh5dLvo49geBhQ_Q", 'https://yt3.ggpht.com/-fHOmMUmczE8/AAAAAAAAAAI/AAAAAAAAAAA/wmTZGeMHa6k/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Filmy online VOD", "channel/UCR6Ks0-lZuxYIKxNn53O0wQ", 'https://yt3.ggpht.com/-ULKWn7bMG2g/AAAAAAAAAAI/AAAAAAAAAAA/2yIlAl6cDh8/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("TRWAM VOD", "channel/UCObLv4zF3TKdgNl9s1JjQ_g", 'https://yt3.ggpht.com/-s39S_vB7Fng/AAAAAAAAAAI/AAAAAAAAAAA/xIffMAXAQi4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>MUZYKA<<[/COLOR]", "", ''),
		("NOSPR Live", "channel/UCOTYTsf82BCm09n3qUg7XHA", 'https://yt3.ggpht.com/-lGWHvOBksXs/AAAAAAAAAAI/AAAAAAAAAAA/yKXEcTFPkyQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("", "", ''),
		("[COLOR aqua}>>Rozrywka<<[/COLOR]", "", ''),
		("Historia bez cenzury", "channel/UCRWskElXZvb3q0W5JopPTnQ", 'https://yt3.ggpht.com/-5T2e9wbZ7vo/AAAAAAAAAAI/AAAAAAAAAAA/Jy7C0R4sb0A/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kabarety Abra", "channel/UCNRkRe0QSUTJ-hN50FRjf6g", 'https://yt3.ggpht.com/--zSrJv_wKus/AAAAAAAAAAI/AAAAAAAAAAA/1z4KQLZwR2Q/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("5 sposobów na", "channel/UCLcxQ8h1PX3WgLdgnJHcCxg", 'https://yt3.ggpht.com/-IkUvQ9Qeapc/AAAAAAAAAAI/AAAAAAAAAAA/Lo6qpHngY3k/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Matura to bzdura", "user/MaturaToBzduraTV", 'https://yt3.ggpht.com/-Oqe7cQetdXQ/AAAAAAAAAAI/AAAAAAAAAAA/rJDJYQB9f10/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Wardęga", "user/wardegasa", 'https://yt3.ggpht.com/-Oq_0fYkTUwk/AAAAAAAAAAI/AAAAAAAAAAA/x6fdQ9E6j0E/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("AbstrachujeTV", "user/AbstrachujeTV", 'https://yt3.ggpht.com/-CLUN4H-kZwY/AAAAAAAAAAI/AAAAAAAAAAA/Q9vkLR_OYRg/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Niekryty Krytyk", "user/Macfra84", 'https://yt3.ggpht.com/-C-yrBjAt9uY/AAAAAAAAAAI/AAAAAAAAAAA/aVkGtehQO1Q/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Polimaty", "channel/UCCRXm_ENFXkMl7_iwERqlrQ", 'https://yt3.ggpht.com/-ffHb-wFjG0g/AAAAAAAAAAI/AAAAAAAAAAA/SvqRoGGGlNY/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("ROJSON", "user/ROJOV13", 'https://yt3.ggpht.com/--vpfLQJbhqQ/AAAAAAAAAAI/AAAAAAAAAAA/AoW4OU0kO_g/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Cezary Pazura", "channel/UCY_fyIMTLLOZgmkuUYo6JKw", 'https://yt3.ggpht.com/-G3w8cGQGVeg/AAAAAAAAAAI/AAAAAAAAAAA/57O0NEyRoJk/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("UchoPrezesa", "channel/UCggq3qvOrrM2u9gRL7oMOfA", 'https://yt3.ggpht.com/-gnvkUX7U9ko/AAAAAAAAAAI/AAAAAAAAAAA/oFaZ-dDF0P0/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kabaretowy Szał!", "channel/UCJIuIuxFuX_Jp4nwjhddRxw", 'https://yt3.ggpht.com/-bz3yJIeIvJg/AAAAAAAAAAI/AAAAAAAAAAA/5031zEi5wWY/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("SciFun", "user/SciTeraz", 'https://yt3.ggpht.com/-TDCqSVWg8RE/AAAAAAAAAAI/AAAAAAAAAAA/TDU6Fq3Grok/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Nauka. To Lubię", "user/naukatolubie", 'https://yt3.ggpht.com/-IoMziu_eEn0/AAAAAAAAAAI/AAAAAAAAAAA/ryzCwy288mc/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Poszukiwacz", "user/EdiPoszukiwacz", 'https://yt3.ggpht.com/-Cp0pZY1qpos/AAAAAAAAAAI/AAAAAAAAAAA/w137N0WcfIY/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("A co my tu mamy", "channel/UCT1DOD6aHZsi8b2ubD-OhNQ", 'https://yt3.ggpht.com/-zn_KVqD-PvM/AAAAAAAAAAI/AAAAAAAAAAA/HHzIC29h9dY/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("SerafinTV", "user/PoradySerafina", 'https://yt3.ggpht.com/-6o-CCgvK1b0/AAAAAAAAAAI/AAAAAAAAAAA/Nah1t8nLA1Y/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Sprawdzam Jak", "channel/UCSBmpo4ksx-1GzKorS4YOnQ", 'https://yt3.ggpht.com/-4TQAlNLvV3M/AAAAAAAAAAI/AAAAAAAAAAA/cgx6X_fD4jI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Szparagi", "user/szparagii", 'https://yt3.ggpht.com/-EtFGwCgP_94/AAAAAAAAAAI/AAAAAAAAAAA/P1s6FzjEIqg/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>Kuchnia[/COLOR]<<", "", ''),
		("Jedz co chcesz", "user/kuchniajedzcochcesz", 'https://yt3.ggpht.com/-M7W-UcMXxaM/AAAAAAAAAAI/AAAAAAAAAAA/VLCf4MHEAC4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kocham gotoawć", "user/paei100", 'https://yt3.ggpht.com/-LCE99xQw77I/AAAAAAAAAAI/AAAAAAAAAAA/sAxZdVq5Am8/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Gotuj to sam", "channel/UCumHw15XoDAWEBzO0jK5VUg", 'https://yt3.ggpht.com/-vab_5R6w3JM/AAAAAAAAAAI/AAAAAAAAAAA/HKcrKNsVq0o/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Skutecznie TV", "user/SkutecznieTv", 'https://yt3.ggpht.com/-Jj-RkLkOtaM/AAAAAAAAAAI/AAAAAAAAAAA/AwjHvkf9ARo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kuchnia Renaty", "user/KuchniaRenaty", 'https://yt3.ggpht.com/-gxx0CbBlUlo/AAAAAAAAAAI/AAAAAAAAAAA/GdGuEywanvM/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Ugotowani TV", "user/ugotowanitv", 'https://yt3.ggpht.com/-YMCfmsxp-nc/AAAAAAAAAAI/AAAAAAAAAAA/rLu-Y1VHudA/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("szuszgotuje", "user/szuszgotuje", 'https://yt3.ggpht.com/-92XAUFwcvDU/AAAAAAAAAAI/AAAAAAAAAAA/eH_niQi6Hlk/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("VideoKuchnia", "user/videokuchniapl", 'https://yt3.ggpht.com/--IDnD_ORIuU/AAAAAAAAAAI/AAAAAAAAAAA/8phdq14t7Fo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kuchnia Lidla", "user/LidlPolskaPL", 'https://yt3.ggpht.com/-I-mw2pWYdZw/AAAAAAAAAAI/AAAAAAAAAAA/-CZ2E4rFNPw/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("The Food Emperor", "user/FoodEmperor", 'https://yt3.ggpht.com/-Tqdv7oOw2gU/AAAAAAAAAAI/AAAAAAAAAAA/PBAr2WnMmKA/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kotlet.TV", "user/kotlettv", 'https://yt3.ggpht.com/-bDZaaiJ2HMU/AAAAAAAAAAI/AAAAAAAAAAA/TA5n0upVvr4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Czajnikowy.pl - dobra herbata!", "user/mailpatpl", 'https://yt3.ggpht.com/-sNPBROqFP5A/AAAAAAAAAAI/AAAAAAAAAAA/SRQq4u6ax-U/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Dorota Kamińska", "user/pozytywnakuchnia", 'https://yt3.ggpht.com/-xgGM58l3P1o/AAAAAAAAAAI/AAAAAAAAAAA/f6PPLkMsbwo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kuchnia Orientalna", "user/PrzepisyChinskie", 'https://yt3.ggpht.com/-0bljo5rogjU/AAAAAAAAAAI/AAAAAAAAAAA/8mObEsvay2U/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kuzyn Hindus", "user/VirenGotuje", 'https://yt3.ggpht.com/-fRNZ_-ioN7M/AAAAAAAAAAI/AAAAAAAAAAA/YvXo3i_q0cI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Pascal Brodnicki", "user/BrodnickiPascal", 'https://yt3.ggpht.com/-2okGcbzZyJo/AAAAAAAAAAI/AAAAAAAAAAA/lDGvYkQ4EK0/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kuchnia Banalna", "channel/UCCfkWzDYYkIOFrZdp8Z9eDA", 'https://yt3.ggpht.com/-VTRPDyuzO1g/AAAAAAAAAAI/AAAAAAAAAAA/Lc4PGbdQR5I/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>Motoryzacja<<[/COLOR]", "", ''),
		("KicksterTV", "channel/UCE59JfgJn06qFVHES99M_KQ", 'https://yt3.ggpht.com/-ThDhOSFbkdU/AAAAAAAAAAI/AAAAAAAAAAA/BsFIhFIEWbo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Moto Doradca", "user/motoopiniecom", 'https://yt3.ggpht.com/-Ks7tl4uqqnQ/AAAAAAAAAAI/AAAAAAAAAAA/Mjyg9eERFq0/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Moto Doradca", "user/motoopiniecom", 'https://yt3.ggpht.com/-Ks7tl4uqqnQ/AAAAAAAAAAI/AAAAAAAAAAA/Mjyg9eERFq0/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Zachar OFF", "user/ZacharOFFpl", 'https://yt3.ggpht.com/-4lc0y2Mpq3A/AAAAAAAAAAI/AAAAAAAAAAA/Mt_L_nq6dgI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Auto Świat", "user/autoswiatv", 'https://yt3.ggpht.com/-hwxhLW4mgBo/AAAAAAAAAAI/AAAAAAAAAAA/olMYzJ5jVwg/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("AutoCentrum.pl", "user/AutoCentrumKropkaPl", 'https://yt3.ggpht.com/-L59v-u-YkNA/AAAAAAAAAAI/AAAAAAAAAAA/pD1xygHQR08/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>Kino<<[/COLOR]", "", ''),
		("Sfilmowani", "user/SfilmowaniTV/", 'https://yt3.ggpht.com/-SkqTbuqpbQk/AAAAAAAAAAI/AAAAAAAAAAA/2a2mfBpj-Dk/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Skazany na film", "channel/UC8ROk73ZAWnDk6VS5kXTzVQ", 'https://yt3.ggpht.com/-rK7ilpreyTw/AAAAAAAAAAI/AAAAAAAAAAA/xab9vLK55-4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Na Gałęzi", "user/NaGalezi", 'https://yt3.ggpht.com/-tHutBYuXZpg/AAAAAAAAAAI/AAAAAAAAAAA/P_FXYkTmuUw/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("jakbyniepaczec", "user/jakbyniepaczec/", 'https://yt3.ggpht.com/-oLZ0U-s3Vao/AAAAAAAAAAI/AAAAAAAAAAA/4gxbQzzOK_Y/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Tylko Kino", "user/totylkokino", 'https://yt3.ggpht.com/-5qnkr3cmyBE/AAAAAAAAAAI/AAAAAAAAAAA/cWbY71lVuxs/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>Sport<<[/COLOR]", "", ''),
		("Łączy nas piłka", "user/LaczyNasPilka", 'https://yt3.ggpht.com/-m4gxNAoIHR0/AAAAAAAAAAI/AAAAAAAAAAA/EjWm232tx5E/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Przeglad Sportowy", "user/PrzegladSportowy", 'https://yt3.ggpht.com/-TQ1KW7tu4N4/AAAAAAAAAAI/AAAAAAAAAAA/4j81jfubwxA/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Footroll", "user/HalaDzieci", 'https://yt3.ggpht.com/-0mGCyRw4pc0/AAAAAAAAAAI/AAAAAAAAAAA/X5qL6ZJFVoU/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>Cherry Team<<[/COLOR]", "", ''),
		("Cherry TV", "channel/UCrt7prcqcMO0k90xxh9snoA", 'https://yt3.ggpht.com/-ceoWQJ7bRQI/AAAAAAAAAAI/AAAAAAAAAAA/L2OyhrZQJIQ/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("MBox", "channel/UCUz47-XU5xpec8z2194YO3Q/videos", 'https://yt3.ggpht.com/-8s-5LvWRap8/AAAAAAAAAAI/AAAAAAAAAAA/N4rQBuuJnlY/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Piotr Kowalik", "channel/UCA6IEPvJoPXXgJlpJ4IC_Jw", 'https://yt3.ggpht.com/-EJWGpWIbwUQ/AAAAAAAAAAI/AAAAAAAAAAA/k74Vt1e0vqo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("", "", ''),
		("[COLOR aqua]>>Kids<<[/COLOR]", "", ''),
		("Piosenki Dla Dzieci", "channel/UCgDquvUHbtJ7bXXjCEXH-Pw", 'https://yt3.ggpht.com/-2ZjDKGOgyf4/AAAAAAAAAAI/AAAAAAAAAAA/SBy0wQEwIBE/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Kredka i Ołówek - rysuj z nami!", "channel/UC41yk8w55ZRGfIDmhOPxL0g", 'https://yt3.ggpht.com/-iTi0ZW9pg2k/AAAAAAAAAAI/AAAAAAAAAAA/B056Z-5O3gI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Spiewaj z nami", "channel/UC4WXwFqbiNO0fCi0j5vuerg", 'https://yt3.ggpht.com/-Om9nJVHirAc/AAAAAAAAAAI/AAAAAAAAAAA/UauZzQ8dsGc/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("RosNutki TV", "channel/UC7HDXQHPJEvUBDQbPpcB9bw", 'https://yt3.ggpht.com/-OM8rJ5o2DU0/AAAAAAAAAAI/AAAAAAAAAAA/GOoQ-t8Irh4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Dziecko TV", "channel/UCMaF1YDLWnHUDi1FdcE0VKw", 'https://yt3.ggpht.com/-MwLNqKyNafc/AAAAAAAAAAI/AAAAAAAAAAA/gZpucEq2JFo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("Smok Edzio", "channel/UC2Wm5cPUclK1tlVEG6e_ntw", 'https://yt3.ggpht.com/-sGNUYUxyUkA/AAAAAAAAAAI/AAAAAAAAAAA/yokHvP-BRBY/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		("BZYK tv", "user/Szwendaczkowy", 'https://yt3.ggpht.com/-MNCWnHZoNb0/AAAAAAAAAAI/AAAAAAAAAAA/KySSvHRr_nU/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg'),
		
		
]



# Entry point
def run():
    plugintools.log("mboxtime.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("mboxtime.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()