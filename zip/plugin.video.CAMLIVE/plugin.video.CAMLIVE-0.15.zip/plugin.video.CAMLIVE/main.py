# -*- coding: UTF-8 -*-
import urllib, urllib2, re, xbmc, xbmcplugin, xbmcgui, xbmc, xbmcaddon, HTMLParser, os
import requests
from resources.lib.libraries import source_utils, dom_parser, client, cleantitle
import sys

reload(sys)
sys.setdefaultencoding('utf8')

s = requests.Session()


def CATEGORIES():

    addDir('Plaża i morze', 'https://www.webcamera.pl/kategoria,plaze-i-morze', 3, 'search.jpg','', True)
    addDir('Miasta', 'https://www.webcamera.pl/kategoria,miasta', 3, 'search.jpg','', True)
    addDir('Stacje Narciarskie', 'https://www.webcamera.pl/kategoria,stacje-narciarskie', 3, 'search.jpg','', True)
    addDir('Inne', 'https://www.webcamera.pl/kategoria,inne', 3, 'search.jpg','', True)


def addDir(name, url, mode, iconimage,thumb, isFolder=True, total=1):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    url = thumb
    liz.setArt({'thumb': url,
                'icon': url,
                'fanart': url})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder, totalItems=total)
    return ok


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2 :
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/') :
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)) :
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params['url'])
except:
    pass
try:
    name = urllib.unquote_plus(params['name'])
except:
    pass
try:
    mode = int(params['mode'])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params['iconimage'])
except:
    pass


if mode == 3:
    url = urllib.unquote_plus(params['url'])
    content = s.get(url).content
    result = client.parseDOM(content, 'div', {'class': 'inlinecam inlinecam-fixed '})
    for kamera in result:
        try:
            tytul = str(client.parseDOM(kamera, 'a', ret='title')[0]).replace("Przejdź do kamery ","").replace("NOWOŚĆ","").replace("Nowość","")
            zdjecie = client.parseDOM(kamera, 'img', ret='data-src')[0]
            link = client.parseDOM(kamera, 'a', ret='href')[0]
            addDir(tytul, str(link), 10, str(zdjecie) ,str(zdjecie), isFolder=False)
        except:
            continue

if mode == None or url == None or len(url) < 1 :
    CATEGORIES()

elif mode == 10:
    hdr = {'User-Agent': 'Mozilla/5.0'}
    url = urllib.unquote_plus(params['url'])
    content = s.get(url, headers=hdr).content
    linki = client.parseDOM(content, 'link', ret='href')
    link = ''
    for item in linki:
        if 'player' in item and 'html' in item:
            link = item
    content = s.get(link, headers=hdr).content
    video_link = client.parseDOM(content, 'video', ret='src')[0]
    xbmc.Player().play("https:" + str(video_link))

xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)
xbmcplugin.endOfDirectory(int(sys.argv[1]))