import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin

def CATEGORIES():
   addDir3('Radio PRL','http://mbox.one.pl/time/radioprl.txt',3,'http://mbox.one.pl/time/logoprl.png','','')
   addDir3('Radio 90','http://mbox.one.pl/time/radio90.txt',4,'http://mbox.one.pl/time/logo9.png','','')
   addDir3('Radio Slonsk','http://mbox.one.pl/time/radioober.txt',5,'http://mbox.one.pl/time/logoober.png','','')
   addDir3('Radio Relax','http://mbox.one.pl/time/relax.txt',6,'http://mbox.one.pl/time/logorl.png','','')
   addDir3('Radio Kino','http://mbox.one.pl/time/movies.txt',7,'http://mbox.one.pl/time/logomv.png','','')
   addDir3('Radio World','http://mbox.one.pl/time/radiowo.txt',8,'http://mbox.one.pl/time/logowo.png','','')
   addDir3('Radio Christmas','http://mbox.one.pl/time/radionarodzenie.txt',9,'http://mbox.one.pl/time/logonarodzenie.png','','')
   addDir3('Radio Zet','http://mbox.one.pl/time/zet.txt',10,'http://mbox.one.pl/time/logozet.png','','')
   addDir3('RMFon','http://mbox.one.pl/time/rmfon.txt',11,'http://mbox.one.pl/time/rmfon.png','','')
   
   

def radioprl():
   r = requests.get('http://mbox.one.pl/time/radioprl.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')
	 
def radio90():
   r = requests.get('http://mbox.one.pl/time/radio90.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')

def radioober():
   r = requests.get('http://mbox.one.pl/time/radioober.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')

def radiorl():
   r = requests.get('http://mbox.one.pl/time/radiorl.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')

def radiomv():
   r = requests.get('http://mbox.one.pl/time/movies.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')

def radiowo():
   r = requests.get('http://mbox.one.pl/time/radiowo.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')
	 
def radioch():
   r = requests.get('http://mbox.one.pl/time/radionarodzenie.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')
	 
def radiozet():
   r = requests.get('http://mbox.one.pl/time/zet.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')

def rmfon():
   r = requests.get('http://mbox.one.pl/time/rmfon.txt')
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
     addLink(name,link,logo,'','')	 
	 
	 
def addLink(name,url,image,urlType,fanart):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('IsPlayable','true')
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param       
#################################################################################################################

#                               NEED BELOW CHANGED

  
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
     
def addDir2(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
 


              
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        OPEN_URL(url)
elif mode==3:
        radioprl()
elif mode==4:
        radio90()
elif mode==5:
        radioober()
elif mode==6:
        radiorl()
elif mode==7:
        radiomv()
elif mode==8:
        radiowo()
elif mode==9:
        radioch()
elif mode==10:
        radiozet()
elif mode==11:
        rmfon()		




        


xbmcplugin.endOfDirectory(int(sys.argv[1]))
