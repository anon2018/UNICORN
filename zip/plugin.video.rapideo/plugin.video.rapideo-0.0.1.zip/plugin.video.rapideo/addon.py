import sys
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import inputstreamhelper
import re

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.rapideo')
RDSESSID = ''


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def add_item(name, image, folder, payload):
    list_item = xbmcgui.ListItem(label=name)

    if folder:
        list_item.setProperty("IsPlayable", 'false')
    else:
        list_item.setProperty("IsPlayable", 'true')

    list_item.setInfo(type='video', infoLabels={'title': name, 'sorttitle': name})
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(payload),
        listitem=list_item,
        isFolder=folder
    )


def login():
    global RDSESSID

    username = addon.getSetting('username')
    password = addon.getSetting('password')
    url = 'https://www.rapideo.pl/logowanie'

    if username and password:
        response = requests.post(
            url,
            verify=False,
            allow_redirects=False,
            data={'login': username, 'password': password, 'remember': 'off'}
        )
        print(response)
        RDSESSID = response.cookies['RDSESSID']
    else:
        xbmcgui.Dialog().ok('Rapideo Player', 'Podaj dane logowania w ustawieniach wtyczki.')


def home():
    login()

    url = 'https://www.rapideo.pl/twoje_pliki'
    response = requests.post(
        url,
        verify=False,
        cookies={'RDSESSID': RDSESSID},
        data={'downloadprogress': '1'}
    ).json()
    print(response)
    for item in response.get('StandardFiles', []):
        filename = item.get('filename', 'no title').encode('utf-8', 'ignore')
        movie_url = item.get('movie_url', None)
        status = item.get('status', '').encode('utf-8', 'ignore')
        direct = item.get('download_url', '')
        expire = item.get('expire_date', '').encode('utf-8', 'ignore')
        filesize = item.get('filesize', '').encode('utf-8', 'ignore')
        title = filename + '  (wygasa: ' + expire + ')  -  ' + filesize

        if status == 'finish' and movie_url:
            add_item(title, '', False, {'mode': 'play', 'movie_url': movie_url, 'direct_link': direct, 'RDSESSID': RDSESSID})

    xbmcplugin.endOfDirectory(addon_handle)


def play():
    url = params.get('movie_url', None)
    direct_url = params.get('direct_link', None)
    session = params.get('RDSESSID', None)
    response = requests.get(
        url,
        verify=False,
        cookies={'RDSESSID': session}
    )

    if addon.getSetting('inputstream') == 'true':
        for item in re.findall(r'file:.+"', response.content):
            if 'm3u8' in item:
                stream_url = re.findall(r'".+"', item.rstrip('\r\n'))[0].replace('"', '')
                is_helper = inputstreamhelper.Helper('hls')
                if is_helper.check_inputstream():
                    play_item = xbmcgui.ListItem(path=stream_url)
                    play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    play_item.setMimeType('application/vnd.apple.mpegurl')
                    play_item.setContentLookup(False)
    else:
        play_item = xbmcgui.ListItem(path=direct_url)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'play':
        play()
